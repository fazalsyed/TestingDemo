//
//  Service.swift
//  LoginUI
//
//  Created by syed fazal abbas on 24/09/23.
//

import Foundation



class Service : NSObject{
    
    enum ServiceError: Error {
        case invalidURL
        case noData
        case invalidResponse
    }
    static let shared = Service()
    
    func Employe(completion : @escaping (EmplodeModel?,Error?) -> ()){
        let urlString = "https://dummy.restapiexample.com/api/v1/employees"
        guard let url = URL(string: urlString) else {return}
        URLSession.shared.dataTask(with: url) { (data, response, err) in
            if let err = err{
                completion(nil,err)
                print("Failes to fetched courses:",err)
                return
            }
            guard let data = data else {return}
            do{
                let courses = try JSONDecoder().decode(EmplodeModel.self, from: data)
                DispatchQueue.main.sync {
                    completion(courses,nil)
                }
            }
            catch let jsonError{
                print("Failed to decode:", jsonError)
            }
        }.resume()
    }
    func product(completion: @escaping (Result<[ProductModel], Error>) -> Void) {
        let urlString = "https://fakestoreapi.com/products"
        guard let url = URL(string: urlString) else {
            completion(.failure(ServiceError.invalidURL))
            return
        }
        URLSession.shared.dataTask(with: url) { (data, response, error) in
            if let error = error {
                completion(.failure(error))
                print("Failed to fetch data:", error)
                return
            }
            guard let response = response as? HTTPURLResponse,(200..<299).contains(response.statusCode) else{
                completion(.failure(ServiceError.invalidResponse))
                return
            }
            guard  let data = data else {
                completion(.failure(ServiceError.noData))
                return
            }
            do {
                let course = try JSONDecoder().decode([ProductModel].self, from: data)
                DispatchQueue.main.async {
                    completion(.success(course))
                }
            } catch let jsonError {
                print("Failed to decode:", jsonError)
            }
        }.resume()
    }
    func cart(completion: @escaping (Result <[ProductData], Error>) -> Void) {
        let urlString = "https://fakestoreapi.com/products"
        guard let url = URL(string: urlString) else {
            completion(.failure(ServiceError.invalidURL))
            return
        }
        URLSession.shared.dataTask(with: url) { (data, response, error) in
            if let error = error {
                completion(.failure(error))
                print("Failed to fetch data:", error)
                return
            }
            guard let response = response as? HTTPURLResponse,(200..<299).contains(response.statusCode) else{
                completion(.failure(ServiceError.invalidResponse))
                return
            }
            guard let data = data else {
                completion(.failure(ServiceError.noData))
                return
            }
            do {
                let fetchedData = try JSONDecoder().decode([ProductData].self, from: data)
                DispatchQueue.main.async { // Use async instead of sync
                    completion(.success(fetchedData))
                }
            } catch let jsonError {
                print("Failed to decode:", jsonError)
            }
        }.resume()
    }
    func Post(completion : @escaping (Result <[PostModel],Error>) -> Void){
        let urlString = "https://jsonplaceholder.typicode.com/posts"
        guard let url = URL(string: urlString) else {
            completion(.failure(ServiceError.invalidURL))
            return
        }
        URLSession.shared.dataTask(with: url) { (data, response, error) in
            if let error = error{
                completion(.failure(error))
                print("Failes to fetched courses:",error)
                return
            }
            guard let response = response as? HTTPURLResponse,(200..<299).contains(response.statusCode) else{
                completion(.failure(ServiceError.invalidResponse))
                return
            }
            guard let data = data else {
                completion(.failure(ServiceError.noData))
                return
            }
            do{
                let courses = try JSONDecoder().decode([PostModel].self, from: data)
                DispatchQueue.main.sync {
                    completion(.success(courses))
                }
            }
            catch let jsonError{
                print("Failed to decode:", jsonError)
            }
        }.resume()
    }
    
    func Comment(completion : @escaping ([CommentModel]?,Error?) -> ()){
        let urlString = "https://jsonplaceholder.typicode.com/posts/1/comments"
        guard let url = URL(string: urlString) else {return}
        URLSession.shared.dataTask(with: url) { (data, response, err) in
            if let err = err{
                completion(nil,err)
                print("Failes to fetched courses:",err)
                return
            }
            guard let data = data else {return}
            do{
                let courses = try JSONDecoder().decode([CommentModel].self, from: data)
                DispatchQueue.main.sync {
                    completion(courses,nil)
                }
            }
            catch let jsonError{
                print("Failed to decode:", jsonError)
            }
        }.resume()
    }
    func Entites(completion : @escaping (EnterieModel?,Error?) -> ()){
        let urlString = "https://api.publicapis.org/entries"
        guard let url = URL(string: urlString) else {return}
        URLSession.shared.dataTask(with: url) { (data, response, err) in
            if let err = err{
                completion(nil,err)
                print("Failes to fetched courses:",err)
                return
            }
            guard let data = data else {return}
            do{
                let courses = try JSONDecoder().decode(EnterieModel.self, from: data)
                DispatchQueue.main.sync {
                    completion(courses,nil)
                }
            }
            catch let jsonError{
                print("Failed to decode:", jsonError)
            }
        }.resume()
    }
    
    func Colure(completion : @escaping ([ColorModel]?,Error?) -> ()){
        let urlString = "https://www.colourlovers.com/api/colors/new?format=json"
        guard let url = URL(string: urlString) else {return}
        URLSession.shared.dataTask(with: url) { (data, response, err) in
            if let err = err{
                completion(nil,err)
                print("Failes to fetched courses:",err)
                return
            }
            guard let data = data else {return}
            do{
                let courses = try JSONDecoder().decode([ColorModel].self, from: data)
                DispatchQueue.main.sync {
                    completion(courses,nil)
                }
            }
            catch let jsonError{
                print("Failed to decode:", jsonError)
            }
        }.resume()
    }
    func aqua(completion : @escaping ([Aqua]?,Error?) -> ()){
        let urlString = "https://color.serialif.com/aquamarine"
        guard let url = URL(string: urlString) else {return}
        URLSession.shared.dataTask(with: url) { (data, response, err) in
            if let err = err{
                completion(nil,err)
                print("Failes to fetched courses:",err)
                return
            }
            guard let data = data else {return}
            do{
                let courses = try JSONDecoder().decode([Aqua].self, from: data)
                DispatchQueue.main.sync {
                    completion(courses,nil)
                }
            }
            catch let jsonError{
                print("Failed to decode:", jsonError)
            }
        }.resume()
    }
    func code(completion: @escaping ([codeModel]?, Error?) -> Void) {
        let urlString = "https://api.shrtco.de/v2/shorten?url=example.org/very/long/link.html"
        
        guard let url = URL(string: urlString) else {
            completion(nil, NSError(domain: "InvalidURL", code: 0, userInfo: nil))
            return
        }
        
        URLSession.shared.dataTask(with: url) { (data, response, error) in
            if let error = error {
                completion(nil, error)
                print("Failed to fetch data:", error)
                return
            }
            
            guard let data = data else {
                completion(nil, NSError(domain: "NoData", code: 0, userInfo: nil))
                return
            }
            
            do {
                let decoder = JSONDecoder()
                let response = try decoder.decode(codeModel.self, from: data)
                DispatchQueue.main.async {
                    completion([response], nil)
                }
            } catch let jsonError {
                print("Failed to decode JSON:", jsonError)
                completion(nil, jsonError)
            }
        }.resume()
    }
    func url(completion: @escaping (urlModel?, Error?) -> Void) {
        let urlString = "https://urlhaus-api.abuse.ch/v1/urls/recent/limit/3/"
        
        guard let url = URL(string: urlString) else {
            completion(nil, NSError(domain: "InvalidURL", code: 0, userInfo: nil))
            return
        }
        
        URLSession.shared.dataTask(with: url) { (data, response, error) in
            if let error = error {
                completion(nil, error)
                print("Failed to fetch data:", error)
                return
            }
            
            guard let data = data else {
                completion(nil, NSError(domain: "NoData", code: 0, userInfo: nil))
                return
            }
            
            do {
                let decoder = JSONDecoder()
                let response = try decoder.decode(urlModel.self, from: data)
                DispatchQueue.main.async {
                    completion(response, nil)
                }
            } catch let jsonError {
                print("Failed to decode JSON:", jsonError)
                completion(nil, jsonError)
            }
        }.resume()
    }
    func bre(completion : @escaping ([breModel]?,Error?) -> ()){
        let urlString = "https://api.openbrewerydb.org/breweries"
        guard let url = URL(string: urlString) else {return}
        URLSession.shared.dataTask(with: url) { (data, response, err) in
            if let err = err{
                completion(nil,err)
                print("Failes to fetched courses:",err)
                return
            }
            guard let data = data else {return}
            do{
                let courses = try JSONDecoder().decode([breModel].self, from: data)
                DispatchQueue.main.sync {
                    completion(courses,nil)
                }
            }
            catch let jsonError{
                print("Failed to decode:", jsonError)
            }
        }.resume()
    }
    func beers(completion : @escaping ([beersModal]?,Error?) -> ()){
        let urlString = "https://api.punkapi.com/v2/beers"
        guard let url = URL(string: urlString) else {return}
        URLSession.shared.dataTask(with: url) { (data, response, err) in
            if let err = err{
                completion(nil,err)
                print("Failes to fetched courses:",err)
                return
            }
            guard let data = data else {return}
            do{
                let courses = try JSONDecoder().decode([beersModal].self, from: data)
                DispatchQueue.main.sync {
                    completion(courses,nil)
                }
            }
            catch let jsonError{
                print("Failed to decode:", jsonError)
            }
        }.resume()
    }
    func auction(completion : @escaping ([auctionData]?,Error?) -> ()){
        let urlString = "https://api.punkapi.com/v2/beers"
        guard let url = URL(string: urlString) else {return}
        URLSession.shared.dataTask(with: url) { (data, response, err) in
            if let err = err{
                completion(nil,err)
                print("Failes to fetched courses:",err)
                return
            }
            guard let data = data else {return}
            do{
                let courses = try JSONDecoder().decode([auctionData].self, from: data)
                DispatchQueue.main.sync {
                    completion(courses,nil)
                }
            }
            catch let jsonError{
                print("Failed to decode:", jsonError)
            }
        }.resume()
    }
    func activity(completion : @escaping ([activityModel]?,Error?) -> ()){
        let urlString = "https://www.boredapi.com/api/activity"
        guard let url = URL(string: urlString) else {return}
        URLSession.shared.dataTask(with: url) { (data, response, err) in
            if let err = err{
                completion(nil,err)
                print("Failes to fetched courses:",err)
                return
            }
            guard let data = data else {return}
            do{
                let courses = try JSONDecoder().decode(activityModel.self, from: data)
                DispatchQueue.main.sync {
                    completion([courses],nil)
                }
            }
            catch let jsonError{
                print("Failed to decode:", jsonError)
            }
        }.resume()
    }
    func Deals(completion : @escaping ([DealsModel]?,Error?) -> ()){
        let urlString = "https://www.cheapshark.com/api/1.0/deals?upperPrice=15"
        guard let url = URL(string: urlString) else {return}
        URLSession.shared.dataTask(with: url) { (data, response, err) in
            if let err = err{
                completion(nil,err)
                print("Failes to fetched courses:",err)
                return
            }
            guard let data = data else {return}
            do{
                let courses = try JSONDecoder().decode([DealsModel].self, from: data)
                DispatchQueue.main.sync {
                    completion(courses,nil)
                }
            }
            catch let jsonError{
                print("Failed to decode:", jsonError)
            }
        }.resume()
    }
    func Feature(completion : @escaping (featureModel?,Error?) -> ()){
        let urlString = "https://www.dnd5eapi.co/api/features"
        guard let url = URL(string: urlString) else {return}
        URLSession.shared.dataTask(with: url) { (data, response, err) in
            if let err = err{
                completion(nil,err)
                print("Failes to fetched courses:",err)
                return
            }
            guard let data = data else {return}
            do{
                let courses = try JSONDecoder().decode(featureModel?.self, from: data)
                DispatchQueue.main.sync {
                    completion(courses,nil)
                }
            }
            catch let jsonError{
                print("Failed to decode:", jsonError)
            }
        }.resume()
    }
    func ticket(completion : @escaping ([ticketModel]?,Error?) -> ()){
        let urlString = "https://api.wazirx.com/sapi/v1/tickers/24hr"
        guard let url = URL(string: urlString) else {return}
        URLSession.shared.dataTask(with: url) { (data, response, err) in
            if let err = err{
                completion(nil,err)
                print("Failes to fetched courses:",err)
                return
            }
            guard let data = data else {return}
            do{
                let courses = try JSONDecoder().decode([ticketModel]?.self, from: data)
                DispatchQueue.main.sync {
                    completion(courses,nil)
                }
            }
            catch let jsonError{
                print("Failed to decode:", jsonError)
            }
        }.resume()
    }
    func engine(completion : @escaping ([EngineModel]?,Error?) -> ()){
        let urlString = "https://api.apicagent.com/?ua=Mozilla/5.0%20(Macintosh;%20Intel%20Mac%20OS%20X%2010_15_5)%20AppleWebKit/537.36%20(KHTML,%20like%20Gecko)%20Chrome/89.0.4389.114%20Safari/537.36"
        guard let url = URL(string: urlString) else {return}
        URLSession.shared.dataTask(with: url) { (data, response, err) in
            if let err = err{
                completion(nil,err)
                print("Failes to fetched courses:",err)
                return
            }
            guard let data = data else {return}
            do{
                let courses = try JSONDecoder().decode([EngineModel]?.self, from: data)
                DispatchQueue.main.sync {
                    completion(courses,nil)
                }
            }
            catch let jsonError{
                print("Failed to decode:", jsonError)
            }
        }.resume()
    }
    
    private let baseUrl = "https://openexchangerates.org/api/latest.json"
    private let appId = "b8170f2960a546378a5ceb06a7bb6f59" // Replace with your API key
    
    func fetchExchangeRates(completion: @escaping (Result<ExchangeRateResponse, Error>) -> Void) {
        let urlString = "\(baseUrl)?app_id=\(appId)"
        
        guard let url = URL(string: urlString) else {
            completion(.failure(ServiceError.invalidURL))
            return
        }
        
        URLSession.shared.dataTask(with: url) { data, response, error in
            if let error = error {
                completion(.failure(error))
                return
            }
            
            guard let data = data else {
                completion(.failure(ServiceError.noData))
                return
            }
            
            do {
                let decoder = JSONDecoder()
                let exchangeRateResponse = try decoder.decode(ExchangeRateResponse.self, from: data)
                completion(.success(exchangeRateResponse))
            } catch {
                completion(.failure(error))
            }
        }.resume()
    }
    func redit(completion: @escaping (Result<[reditModel], Error>) -> Void){
        let urlString = "https://tradestie.com/api/v1/apps/reddit"
        guard let url = URL(string: urlString) else {
            completion(.failure(ServiceError.invalidURL))
            return
        }
        URLSession.shared.dataTask(with: url) { data, response, error in
            if let error = error {
                completion(.failure(error))
                return
            }
            guard let data = data else{
                completion(.failure(ServiceError.noData))
                return
            }
            
            do{
                let courses = try JSONDecoder().decode([reditModel].self,from : data)
                completion(.success(courses))
            }catch{
                completion(.failure(error))
            }
        }.resume()
    }
    
    func character(completion : @escaping (Result <characterModel, Error>) -> Void){
        let urlString = "https://rickandmortyapi.com/api/character/108"
        guard let url = URL(string: urlString) else{
            completion(.failure(ServiceError.invalidURL))
            return
        }
        URLSession.shared.dataTask(with: url) { data, response, error in
            if let error = error{
                completion(.failure(error))
                return
            }
            guard let httpResponse = response as? HTTPURLResponse,
                  (200..<300).contains(httpResponse.statusCode) else {
                return completion(.failure(ServiceError.invalidResponse))
            }
            guard let data = data else{
                completion(.failure(ServiceError.noData))
                return
            }
            do {
                let course = try JSONDecoder().decode(characterModel.self, from: data)
                completion(.success(course))
            }
            catch{
                completion(.failure(error))
            }
        }.resume()
    }
    
    func currency(completion : @escaping (Result <currentPrice ,Error>) -> Void){
        
        let urlString = "https://api.coindesk.com/v1/bpi/currentprice.json"
        guard let url = URL(string: urlString) else{
            completion(.failure(ServiceError.invalidURL))
            return
        }
        URLSession.shared.dataTask(with: url) { data, response, error in
            if let  error = error{
                completion(.failure(error))
                return
            }
            guard let response = response as? HTTPURLResponse,
                  (200..<300).contains(response.statusCode) else{
                return completion(.failure((ServiceError.invalidResponse)))
            }
            guard let data = data else{
                completion(.failure(ServiceError.noData))
                return
            }
            do {
                let course = try JSONDecoder().decode(currentPrice.self, from: data)
                completion(.success(course))
            }
            catch{
                completion(.failure(error))
            }
        }.resume()
    }
    
    func bitcoin(completion : @escaping (Result <[bitcoinModel] ,Error> ) -> Void){
        let urlString = "https://api.coingecko.com/api/v3/coins/markets?vs_currency=usd"
        guard let url = URL(string: urlString) else{
            completion(.failure(ServiceError.invalidURL))
            return
        }
        URLSession.shared.dataTask(with: url) { data, response, error in
            if let error = error {
                completion(.failure(error))
                return
            }
            guard let response = response as?  HTTPURLResponse,(200..<300).contains(response.statusCode) else{
                completion(.failure(ServiceError.invalidResponse))
                return
            }
            guard let data = data else{
                completion(.failure(ServiceError.noData))
                return
            }
            do{
                let response = try JSONDecoder().decode([bitcoinModel].self, from: data)
                completion(.success(response))
            }
            catch{
                completion(.failure(error))
                
            }
        }.resume()
    }
    
    func ticketApi(completion : @escaping (Result<ticketApiModel,Error>) -> Void){
        let urlString = "https://api.coinlore.net/api/tickers/"
        guard let url = URL(string: urlString) else{
            completion(.failure(ServiceError.invalidURL))
            return
        }
        URLSession.shared.dataTask(with: url) { data, response, error in
            if let error = error{
                completion(.failure(error))
                return
            }
            guard let response = response as? HTTPURLResponse,(200..<300).contains(response.statusCode) else{
                completion(.failure(ServiceError.invalidResponse))
                return
            }
            guard let data = data else{
                completion(.failure(ServiceError.noData))
                return
            }
            do{
                let course = try JSONDecoder().decode(ticketApiModel.self, from: data)
                completion(.success(course))
            }
            catch{
                completion(.failure(error))
            }
        }.resume()
    }
    func market(completion : @escaping (Result <[MarketModel],Error>) -> Void){
        let urlString = "https://api.coinstats.app/public/v1/markets?coinId=bitcoin"
        guard let url = URL(string: urlString) else{
            completion(.failure(ServiceError.invalidURL))
            return
        }
        URLSession.shared.dataTask(with: url) { data, response, error in
            if let error = error{
                completion(.failure(error))
                return
            }
            guard let response = response as? HTTPURLResponse,(200..<300).contains(response.statusCode) else{
                completion(.failure(ServiceError.invalidResponse))
                return
            }
            guard let data = data else{
                completion(.failure(ServiceError.noData))
                return
            }
            do {
                let course = try JSONDecoder().decode([MarketModel].self, from: data)
                completion(.success(course))
            }
            catch{
                completion(.failure(error))
            }
        }.resume()
    }
    
    func exchange(completion : @escaping (Result <ExhageModel,Error>) -> Void){
        let urlString = "https://api.exchangerate.host/latest"
        guard let url = URL(string: urlString)  else{
            completion(.failure(ServiceError.invalidURL))
            return
        }
        URLSession.shared.dataTask(with: url) { data, response, error in
            if let error = error{
                completion(.failure(error))
                return
            }
            guard let response = response as? HTTPURLResponse,(200..<300).contains(response.statusCode) else{
                return completion(.failure(ServiceError.invalidResponse))
                
            }
            guard let data = data else{
                completion(.failure(ServiceError.noData))
                return
            }
            do{
                let course = try JSONDecoder().decode(ExhageModel.self, from: data)
                completion(.success(course))
            }
            catch{
                completion(.failure(error))
            }
        }.resume()
    }
    func branch(completion : @escaping (Result <BranchModel ,Error>) -> Void){
        let urlString = "https://ifsc.razorpay.com/YESB0DNB002"
        guard let url = URL(string: urlString) else{
            completion(.failure(ServiceError.invalidURL))
            return
        }
        URLSession.shared.dataTask(with: url) { data, response, error in
            if let error = error{
                completion(.failure(error))
                return
            }
            guard let response = response as? HTTPURLResponse,(200..<300).contains(response.statusCode) else{
                completion(.failure(ServiceError.invalidResponse))
                return
            }
            guard let data = data else{
                completion(.failure(ServiceError.noData))
                return
            }
            do{
                let course = try JSONDecoder().decode(BranchModel.self, from: data)
                completion(.success(course))
            }
            catch{
                completion(.failure(error))
            }
        }.resume()
    }
    func QuoteAsset(completion : @escaping (Result <[assetModel],Error>) -> Void){
        let urlString = "https://api.wazirx.com/sapi/v1/tickers/24hr"
        guard let url = URL(string: urlString) else{
            completion(.failure(ServiceError.invalidURL))
            return
        }
        URLSession.shared.dataTask(with: url) { data, response, error in
            if let error = error{
                completion(.failure(error))
                return
            }
            guard let response = response as? HTTPURLResponse,(200..<300).contains(response.statusCode) else{
                completion(.failure(ServiceError.invalidResponse))
                return
            }
            guard let data = data else{
                completion(.failure(ServiceError.noData))
                return
            }
            do{
                let course = try JSONDecoder().decode([assetModel].self, from: data)
                completion(.success(course))
                return
            }
            catch{
                completion(.failure(error))
            }
        }.resume()
    }
    
    func macintosh(completion : @escaping (Result <Client,Error>) -> Void){
        let urlString = "https://api.apicagent.com/?ua=Mozilla/5.0%20(Macintosh;%20Intel%20Mac%20OS%20X%2010_15_5)%20AppleWebKit/537.36%20(KHTML,%20like%20Gecko)%20Chrome/89.0.4389.114%20Safari/537.36"
        guard let url = URL(string: urlString) else{
            completion(.failure(ServiceError.invalidURL))
            return
        }
        URLSession.shared.dataTask(with: url) { data, response, error in
            if let error = error{
                completion(.failure(error))
                return
            }
            guard let response = response as? HTTPURLResponse,(200..<300).contains(response.statusCode) else{
                completion(.failure(ServiceError.invalidResponse))
                return
            }
            guard let data = data else{
                completion(.failure(ServiceError.noData))
                return
            }
            do {
                let course = try JSONDecoder().decode(Client.self, from: data)
                completion(.success(course))
            }
            catch{
                completion(.failure(error))
            }
        }
    }
    
    func grab(completion : @escaping (Result <GrabModel,Error>) -> Void){
        let urlString = "https://favicongrabber.com/api/grab/github.com"
        guard let url = URL(string: urlString) else{
            completion(.failure(ServiceError.invalidURL))
            return
        }
        URLSession.shared.dataTask(with: url) { data, response, error in
            if let error = error{
                completion(.failure(error))
                return
            }
            guard let response = response as? HTTPURLResponse,(200..<300).contains(response.statusCode) else{
                completion(.failure(ServiceError.invalidResponse))
                return
            }
            guard let data = data else{
                completion(.failure(ServiceError.noData))
                return
            }
            do{
                let course = try JSONDecoder().decode(GrabModel.self, from: data)
                completion(.success(course))
                return
            }
            catch{
                completion(.failure(error))
            }
        }.resume()
    }
    func list(completion : @escaping (Result <[FilterModel],Error>) -> Void){
        let urlString = "https://api.wazirx.com/sapi/v1/tickers/24hr"
        guard let url = URL(string: urlString) else{
            completion(.failure(ServiceError.invalidURL))
            return
        }
        URLSession.shared.dataTask(with: url) { data, response, error in
            if let error = error{
                completion(.failure(error))
                return
            }
            guard let response = response as? HTTPURLResponse,(200..<300).contains(response.statusCode) else{
                completion(.failure(ServiceError.invalidResponse))
                return
            }
            guard let data = data else{
                completion(.failure(ServiceError.noData))
                return
            }
            do{
                let course = try JSONDecoder().decode([FilterModel].self, from: data)
                completion(.success(course))
                return
            }
            catch{
                completion(.failure(error))
            }
        }.resume()
    }
    
    
    func maps(completion : @escaping(Result <[WelcomeElement],Error>) -> Void){
        let urlString = "https://api.opensensemap.org/boxes?model=homeWifi"
        guard let url = URL(string: urlString) else{
            completion(.failure(ServiceError.invalidURL))
            return
        }
        URLSession.shared.dataTask(with: url) { data, response, error in
            if let error = error{
                completion(.failure(error))
                return
            }
            guard let response = response as? HTTPURLResponse,(200..<299).contains(response.statusCode) else{
                completion(.failure(ServiceError.invalidResponse))
                return
            }
            guard let data = data else{
                completion(.failure(ServiceError.noData))
                return
            }
            do{
                let course = try JSONDecoder().decode([WelcomeElement].self, from: data)
                completion(.success(course))
                return
            }
            catch{
                completion(.failure(error))
            }
        }.resume()
    }
    
    func metaData(completion : @escaping (Result<metasDataModel,Error>) -> Void){
        let urlString = "https://api.data.gov.sg/v1/environment/air-temperature"
        guard let url = URL(string: urlString) else{
            completion(.failure(ServiceError.invalidURL))
            return
        }
        URLSession.shared.dataTask(with: url) { data, response, error in
            if let error = error{
                completion(.failure(error))
                return
            }
            guard let response = response as? HTTPURLResponse,(200..<299).contains(response.statusCode) else{
                completion(.failure(ServiceError.invalidResponse))
                return
            }
            guard let data = data else{
                completion(.failure(ServiceError.noData))
                return
            }
            do{
                let course = try JSONDecoder().decode(metasDataModel.self, from: data)
                completion(.success(course))
                return
            }
            catch{
                completion(.failure(error))
            }
        }.resume()
    }
    
    func dict(completion : @escaping(Result <[DictData],Error>) -> Void){
        let urlString = "https://api.dictionaryapi.dev/api/v2/entries/en/digital"
        guard let url = URL(string: urlString) else{
            completion(.failure(ServiceError.invalidURL))
            return
        }
        URLSession.shared.dataTask(with: url) { data, response, error in
            if let error = error {
                completion(.failure(error))
                return
            }
            guard let response = response as? HTTPURLResponse,(200..<299).contains(response.statusCode) else{
                completion(.failure(ServiceError.invalidResponse))
                return
            }
            guard let data = data else{
                completion(.failure(ServiceError.noData))
                return
            }
            do{
                let course = try JSONDecoder().decode([DictData].self, from: data)
                completion(.success(course))
                return
            }
            catch{
                completion(.failure(error))
            }
        }.resume()
    }
    func makeAPIRequest(completion: @escaping (Result<Data, Error>) -> Void) {
        // Define the URL with the API key as a query parameter
        let apiKey = "8a6942796de0f4d8ced47ef6a8023063"
        let urlString = "https://dev.challanger.com/API/Court/getFacility?api_key=" + apiKey
        
        // Create a URL from the string
        if let url = URL(string: urlString) {
            // Create a URLSession task for the request
            let task = URLSession.shared.dataTask(with: url) { data, response, error in
                if let error = error {
                    completion(.failure(error))
                } else if let data = data {
                    completion(.success(data))
                }
            }
            
            // Start the URLSession task
            task.resume()
        }
    }
    
    func TelePort(completion : @escaping (Result<TelePortModel,Error>) -> Void){
        let urlString = "https://api.teleport.org/api/urban_areas/teleport%3A9q8yy/scores/"
        guard let url = URL(string: urlString) else{
            completion(.failure(ServiceError.invalidURL))
            return
        }
        URLSession.shared.dataTask(with: url) { data, response, error in
            if let error = error{
                completion(.failure(error))
            }
            guard let response = response as? HTTPURLResponse,(200..<299).contains(response.statusCode) else{
                completion(.failure(ServiceError.invalidResponse))
                return
            }
            guard let data = data else{
                completion(.failure(ServiceError.noData))
                return
            }
            do{
                let course = try JSONDecoder().decode(TelePortModel.self, from: data)
                completion(.success(course))
            }
            catch{
                completion(.failure(error))
            }
        }.resume()
    }
    
    
    func universities(completion : @escaping (Result<unversitiesModel,Error>) -> Void) {
        let urlString = "https://vpic.nhtsa.dot.gov/api/vehicles/GetVehicleTypesForMake/merc?format=json"
        guard let url = URL(string: urlString) else{
            completion(.failure(ServiceError.invalidURL))
            return
        }
        URLSession.shared.dataTask(with: url) { data, response, error in
            if let error = error {
                completion(.failure(error))
            }
            guard let response = response as? HTTPURLResponse,(200..<299).contains(response.statusCode) else{
                completion(.failure(ServiceError.invalidResponse))
                return
            }
            guard let data = data else{
                completion(.failure(ServiceError.noData))
                return
            }
            do{
                let course = try JSONDecoder().decode(unversitiesModel.self, from: data)
                completion(.success(course))
            }
            catch{
                completion(.failure(error))
            }
        }.resume()
    }
    
    func aster(completion: @escaping (Result<[asterModel], Error>) -> Void) {
        let urlString = "http://www.asterank.com/api/skymorph/search?target=J99TS7A"
        
        guard let url = URL(string: urlString) else {
            completion(.failure(ServiceError.invalidURL))
            return
        }
        
        URLSession.shared.dataTask(with: url) { data, response, error in
            DispatchQueue.main.async {
                if let error = error {
                    completion(.failure(error))
                    return
                }

                guard let httpResponse = response as? HTTPURLResponse,
                      (200..<300).contains(httpResponse.statusCode),
                      httpResponse.allHeaderFields["Content-Type"] as? String == "application/json" else {
                    completion(.failure(ServiceError.invalidResponse))
                    return
                }

                guard let data = data else {
                    completion(.failure(ServiceError.noData))
                    return
                }

                do {
                    let decoder = JSONDecoder()
                    let asterModels = try decoder.decode([asterModel].self, from: data)
                    completion(.success(asterModels))
                } catch {
                    completion(.failure(error))
                }
            }
        }.resume()
    }
}
