//
//  Constant.swift
//  LoginUI
//
//  Created by syed fazal abbas on 04/10/23.
//

import Foundation

enum ServiceError: Error {
    case invalidURL
    case noData
    case invalidResponse
}
