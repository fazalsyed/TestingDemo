//
//  Data.swift
//  LoginUI
//
//  Created by syed fazal abbas on 22/09/23.
//

import Foundation

struct Company {
    var img : String
    var companyName : String
    var CompanyDesc : String
    var FolloweCount : String
    var NewContent : String
}
class DataModel{
    static var ArrCompany = [Company(img: "ic_appleInc", companyName: "Apple Inc.", CompanyDesc: "Apple Inc. is an American multinational technology company known for its consumer electronics, software, and services. It is famous for its iPhone, iPad, Mac, and iOS operating systems.", FolloweCount: "25 follower",NewContent: "New Content"),Company(img: "ic_Microsoft", companyName: "Microsoft Corporation", CompanyDesc: "Microsoft is a global technology company that develops, licenses, and sells computer software, consumer electronics, and personal computers. It is known for Windows, Office, and Azure.", FolloweCount: "30 followers",NewContent: ""),Company(img: "ic_AmazonInc", companyName: "Amazon.com Inc.", CompanyDesc: "Amazon is an American multinational technology and e-commerce company. It is the world's largest online sales company and provider of virtual assistants, cloud computing, and more.", FolloweCount: "45 followers",NewContent: "New Content"),Company(img: "ic_GoogleInc", companyName: "Google", CompanyDesc: " Alphabet Inc. is the parent company of Google. Google is a multinational technology company known for its search engine, online advertising technologies, and various software services.", FolloweCount: "50 followers",NewContent: ""),Company(img: "ic_Facebook", companyName: "Facebook, Inc. ", CompanyDesc: "Facebook, now known as Meta Platforms, Inc., is a social media conglomerate. It owns Facebook, Instagram, WhatsApp, and Oculus VR.", FolloweCount: "70 followers",NewContent: "New Content"),Company(img: "ic_Tesla", companyName: "Tesla, Inc.", CompanyDesc: "Tesla is an electric vehicle and clean energy company. It is known for its electric cars, solar energy products, and innovative technology.", FolloweCount: "15 follower",NewContent: "New Content"),Company(img: "ic_Berkshire", companyName: "Berkshire Hathaway Inc", CompanyDesc: "Berkshire Hathaway is a conglomerate holding company led by Warren Buffett. It owns and manages a range of subsidiary companies, including GEICO, BNSF Railway, and more", FolloweCount: "100 followers",NewContent: "")]
}
