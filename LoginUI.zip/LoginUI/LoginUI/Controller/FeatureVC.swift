//
//  FeatureVC.swift
//  LoginUI
//
//  Created by syed fazal abbas on 26/09/23.
//

import UIKit

class FeatureVC: UIViewController {
    
    var ArrFeature : [resultsDataModel] = []
    @IBOutlet var tblFeature: UITableView!
    override func viewDidLoad() {
        super.viewDidLoad()
        tblFeature.delegate = self
        tblFeature.dataSource = self
        registerXib()
        fetchData()
    }
    func registerXib() {
        tblFeature.register(UINib(nibName: "CellT_Employe", bundle: nil), forCellReuseIdentifier: "CellT_Employe")
    }
    func fetchData(){
        Service.shared.Feature { [weak self] (enterie, error) in
            if let error = error {
                print("Failed to fetch employees:", error)
                return
            }
            
            if let employees = enterie {
                self?.ArrFeature = employees.results
                DispatchQueue.main.async {
                    self?.tblFeature.reloadData()
                }
            }
        }
    }
}
extension FeatureVC : UITableViewDelegate,UITableViewDataSource{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return ArrFeature.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tblFeature.dequeueReusableCell(withIdentifier: "CellT_Employe") as! CellT_Employe
        cell.lbl_EmpName.text = ArrFeature[indexPath.row].url
        cell.lbl_EmpFather.text = ArrFeature[indexPath.row].name
        cell.lbl_Mother.text = ArrFeature[indexPath.row].index
        return cell
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 200
    }
}
