//
//  EmployeDetailVC.swift
//  LoginUI
//
//  Created by syed fazal abbas on 24/09/23.
//

import UIKit

class EmployeDetailVC: UIViewController {
    
    var ArremployeeData: [EmpDataModel] = []
    @IBOutlet var tableView: UITableView!
    override func viewDidLoad() {
        super.viewDidLoad()
        tableView.delegate = self
        tableView.dataSource = self
        fetchData()
        registerxib()
    }
    func registerxib(){
        tableView.register(UINib(nibName: "CellT_Employe", bundle: nil), forCellReuseIdentifier: "CellT_Employe")
    }
    
    func fetchData(){
        Service.shared.Employe { [weak self] (employeeList, error) in
            if let error = error {
                print("Failed to fetch employees:", error)
                return
            }
            
            if let employees = employeeList {
                self?.ArremployeeData = employees.data
                DispatchQueue.main.async {
                    self?.tableView.reloadData()
                }
            }
        }
    }
}
//Marks : UitableViewDelegate & UitableViewDataSource
extension EmployeDetailVC : UITableViewDelegate,UITableViewDataSource{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return ArremployeeData.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "CellT_Employe") as! CellT_Employe
        cell.lbl_EmpName.text = ArremployeeData[indexPath.row].employee_name
        cell.lbl_EmpFather.text = (String(ArremployeeData[indexPath.row].employee_age))
        cell.lbl_Mother.text = (String(ArremployeeData[indexPath.row].employee_salary))
        cell.lbl_EmpBrother.text = (String(ArremployeeData[indexPath.row].id))
        cell.lbl_EmpID.text = ArremployeeData[indexPath.row].employee_name
        cell.lbl_EmpAddress.text = (String(ArremployeeData[indexPath.row].employee_age))
        return cell
    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 200
    }
    
}
