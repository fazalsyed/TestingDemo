//
//  CharacterVC.swift
//  LoginUI
//
//  Created by syed fazal abbas on 04/10/23.
//

import UIKit

class CharacterVC: UIViewController {
    
    var ArrCharacter : [characterModel] = []
    @IBOutlet var tblChracter: UITableView!
    override func viewDidLoad() {
        super.viewDidLoad()
        tblChracter.delegate = self
        tblChracter.dataSource = self
        registerXib()
        fethcdata()
    }
    func registerXib() {
        tblChracter.register(UINib(nibName: "CellT_Employe", bundle: nil), forCellReuseIdentifier: "CellT_Employe")
    }
    func fethcdata(){
        Service.shared.character { [weak self] (result : Result<characterModel,Error>) in
            switch result {
            case .success(let success):
                self?.ArrCharacter.append(success)
                DispatchQueue.main.sync {
                    self?.tblChracter.reloadData()
                }
            case .failure(let failure):
                print("Failed to fetchdat :",failure)
            }
        }
    }
//    func fetchData() {
//        Service.shared.character { [weak self] (result: Result<characterModel, Error>) in
//            switch result {
//            case .success(let enterie):
//                self?.ArrCharacter.append(enterie)
//                DispatchQueue.main.async {
//                    self?.tblChracter.reloadData()
//                }
//            case .failure(let error):
//                print("Failed to fetch employees:", error)
//            }
//        }
//    }
}
extension CharacterVC : UITableViewDelegate,UITableViewDataSource{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return ArrCharacter.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tblChracter.dequeueReusableCell(withIdentifier: "CellT_Employe") as! CellT_Employe
        cell.lbl_EmpName.text = "\(ArrCharacter[indexPath.row].url)"
        cell.lbl_EmpFather.text = ArrCharacter[indexPath.row].origin.name
        cell.lbl_Mother.text = "\(ArrCharacter[indexPath.row].created)"
        cell.lbl_EmpBrother.text = "\(ArrCharacter[indexPath.row].gender)"
        cell.lbl_EmpID.text = "\(ArrCharacter[indexPath.row].episode)"
        cell.lbl_EmpAddress.text = "\(ArrCharacter[indexPath.row].species)"
        return cell
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 200
    }
}
