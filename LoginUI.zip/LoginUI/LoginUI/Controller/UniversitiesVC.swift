//
//  UniversitiesVC.swift
//  LoginUI
//
//  Created by syed fazal abbas on 18/11/23.
//

import UIKit

class UniversitiesVC: UIViewController {

    var ArrUniversites : [unversitiesModel] = []
    @IBOutlet var tbl_universities: UITableView!
    override func viewDidLoad() {
        super.viewDidLoad()
        ApiCall()
        registerXib()
        
    }
    func registerXib() {
        tbl_universities.register(UINib(nibName: "CellT_Employe", bundle: nil), forCellReuseIdentifier: "CellT_Employe")
    }
    //Marks : ApiCall()
    func ApiCall(){
        Service.shared.universities { [weak self] (result : Result<unversitiesModel,Error>)  in
            switch result {
            case .success(let success):
                self?.ArrUniversites.append(success)
                DispatchQueue.main.async {
                    self?.tbl_universities.reloadData()
                }
            case .failure(let failure):
                print("Data Not Fetched \(failure)")
            }
        }
    }
}
//Marks: UITableViewDelgate & UITableViewDataSource
extension UniversitiesVC : UITableViewDelegate,UITableViewDataSource{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return ArrUniversites.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tbl_universities.dequeueReusableCell(withIdentifier: "CellT_Employe") as! CellT_Employe
        cell.lbl_EmpName.text = ArrUniversites[indexPath.row].Message
        cell.lbl_Mother.text = ArrUniversites[indexPath.row].SearchCriteria
        cell.lbl_EmpBrother.text = "\(ArrUniversites[indexPath.row].Count)"
        
        cell.lbl_EmpID.text = ArrUniversites[indexPath.row].Results[indexPath.section].MakeName
        cell.lbl_EmpAddress.text = ArrUniversites[indexPath.row].Results[indexPath.section].VehicleTypeName
        return cell
    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 200
    }
}
