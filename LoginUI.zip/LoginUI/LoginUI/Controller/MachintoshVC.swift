//
//  MachintoshVC.swift
//  LoginUI
//
//  Created by syed fazal abbas on 08/10/23.
//

import UIKit

class MachintoshVC: UIViewController {

    var ArrMachin : [Client] = []
    @IBOutlet var tblMachintosh: UITableView!
    override func viewDidLoad() {
        super.viewDidLoad()
        tblMachintosh.delegate = self
        tblMachintosh.dataSource = self
        registerXib()
        fetchdata()
    }
    func registerXib() {
        tblMachintosh.register(UINib(nibName: "CellT_Employe", bundle: nil), forCellReuseIdentifier: "CellT_Employe")
    }
    func fetchdata(){
        Service.shared.macintosh { [weak self] (result : Result <Client,Error>) in
            switch result {
            case .success(let success):
                self?.ArrMachin.append(success)
                DispatchQueue.main.sync {
                    self?.tblMachintosh.reloadData()
                }
                print("Data fetched successfully:", success)
            case .failure(let failure):
                print("Data Not Fetched:", failure)
            }
        }
    }

}
extension MachintoshVC : UITableViewDelegate,UITableViewDataSource{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return ArrMachin.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tblMachintosh.dequeueReusableCell(withIdentifier: "CellT_Employe") as! CellT_Employe
        cell.lbl_EmpName.text = ArrMachin[indexPath.row].engineVersion
        cell.lbl_Mother.text = ArrMachin[indexPath.row].engine
        cell.lbl_EmpBrother.text = ArrMachin[indexPath.row].type
        cell.lbl_EmpID.text = ArrMachin[indexPath.row].name
        cell.lbl_EmpAddress.text = ArrMachin[indexPath.row].version
        return cell
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 200
    }
}
