//
//  PostVC.swift
//  LoginUI
//
//  Created by syed fazal abbas on 24/09/23.
//

import UIKit

class PostVC: UIViewController {
    
    var ArrPost : [PostModel] = []
    @IBOutlet var tblPost: UITableView!
    override func viewDidLoad() {
        super.viewDidLoad()
        tblPost.delegate = self
        tblPost.dataSource = self
        registerXib()
        fetchData()
    }
    func registerXib() {
        tblPost.register(UINib(nibName: "CellT_Employe", bundle: nil), forCellReuseIdentifier: "CellT_Employe")
    }
    func fetchData() {
        Service.shared.Post { [weak self] (result : Result<[PostModel],Error>) in
            switch result {
            case .success(let success):
                self?.ArrPost = success
                DispatchQueue.main.async {
                    self?.tblPost.reloadData()
                }
            case .failure(let failure):
                print("Data Not Fetched \(failure)")
            }
         
        }
    }
}
//Marks : UItableViewDelegate & UItableViewDataSource
extension PostVC : UITableViewDelegate,UITableViewDataSource{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return ArrPost.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tblPost.dequeueReusableCell(withIdentifier: "CellT_Employe") as! CellT_Employe
        let productData = ArrPost[indexPath.row]
        cell.lbl_EmpName.text = "User ID: \(productData.userId)"
        cell.lbl_EmpFather.text = "Tittle: \(productData.title)"
        cell.lbl_Mother.text = "Prduct ID: \(productData.id)"
        cell.lbl_EmpBrother.text = "Product Body: \(productData.body)"
        return cell
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 200
    }
    
}
