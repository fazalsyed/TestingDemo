//
//  DictVC.swift
//  LoginUI
//
//  Created by syed fazal abbas on 30/10/23.
//

import UIKit

class DictVC: UIViewController {

    var ArrDict : [DictData] = []
    @IBOutlet var tblDict: UITableView!
    override func viewDidLoad() {
        super.viewDidLoad()
        tblDict.dataSource = self
        tblDict.delegate = self
        registerXib()
        ApiCall()
    }
    func registerXib() {
        tblDict.register(UINib(nibName: "CellT_Employe", bundle: nil), forCellReuseIdentifier: "CellT_Employe")
    }
    func ApiCall(){
        Service.shared.makeAPIRequest { result in
            switch result {
            case .success(let data):
                // Process the data
                if let responseString = String(data: data, encoding: .utf8) {
                    print("Response: \(responseString)")
                }
            case .failure(let error):
                // Handle the error
                print("Error: \(error)")
            }
        }
    }

//    func ApiCall(){
//        Service.shared.dict { [weak self] (result : Result<[DictData],Error>) in
//            switch result {
//            case .success(let success):
//                self?.ArrDict = success
//                DispatchQueue.main.sync {
//                    self?.tblDict.reloadData()
//                }
//            case .failure(let failure):
//                print("Data Not Fetched\(failure)")
//            }
//        }
//    }
}
extension DictVC : UITableViewDelegate,UITableViewDataSource{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return ArrDict.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tblDict.dequeueReusableCell(withIdentifier: "CellT_Employe") as! CellT_Employe
        cell.lbl_EmpName.text = ArrDict[indexPath.row].phonetic
        cell.lbl_Mother.text = ArrDict[indexPath.row].license.name
        cell.lbl_EmpBrother.text = ArrDict[indexPath.row].phonetics[indexPath.row].sourceURL
        cell.lbl_EmpID.text = ArrDict[indexPath.row].phonetics[indexPath.section].audio
        cell.lbl_EmpAddress.text = ArrDict[indexPath.row].license.url
        cell.lbl_EmpFather.text = "\(ArrDict[indexPath.row].meanings[indexPath.section].definitions[indexPath.section].antonyms)"
        return cell
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 200
    }
}
