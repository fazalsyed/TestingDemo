//
//  BranchVC.swift
//  LoginUI
//
//  Created by syed fazal abbas on 07/10/23.
//

import UIKit

class BranchVC: UIViewController {

    var ArrBranch : [BranchModel]? = []
    @IBOutlet var tblBranch: UITableView!
    override func viewDidLoad() {
        super.viewDidLoad()
        tblBranch.delegate = self
        tblBranch.dataSource = self
        registerXib()
        fetchdata()
    }
    func registerXib() {
        tblBranch.register(UINib(nibName: "CellT_Employe", bundle: nil), forCellReuseIdentifier: "CellT_Employe")
    }
    func fetchdata(){
        Service.shared.branch { [weak self] (result : Result <BranchModel,Error>) in
            switch result {
            case .success(let success):
                self?.ArrBranch?.append(success)
            case .failure(let failure):
                print("Data Not Fetched :",failure)
            }
        }
    }
}
extension BranchVC : UITableViewDelegate,UITableViewDataSource{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return ArrBranch?.count ?? 0
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tblBranch.dequeueReusableCell(withIdentifier: "CellT_Employe") as! CellT_Employe
        cell.lbl_EmpName.text = ArrBranch?[indexPath.row].address
        cell.lbl_Mother.text = ArrBranch?[indexPath.row].bank
        cell.lbl_EmpBrother.text = ArrBranch?[indexPath.row].bankcode
        cell.lbl_EmpID.text = ArrBranch?[indexPath.row].centre
        cell.lbl_EmpAddress.text = ArrBranch?[indexPath.row].contact
        return cell
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 200
    }
}
