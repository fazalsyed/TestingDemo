//
//  CreateAccountVC.swift
//  LoginUI
//
//  Created by syed fazal abbas on 14/09/23.
//

import UIKit

class CreateAccountVC: UIViewController {
    
    @IBOutlet var txt_MailID: UITextField!
    @IBOutlet var txt_Password: UITextField!
    @IBOutlet var txt_FullName: UITextField!
    @IBOutlet var btn_CreateAccount: UIButton!
    @IBOutlet var vwMain: UIView!
    @IBOutlet var vwCreateAccount: UIView!
    override func viewDidLoad() {
        super.viewDidLoad()
        setUpUI()
    }
    //Mark : UISetup
    func setUpUI(){
        btn_CreateAccount.layer.cornerRadius = 26.0
        vwCreateAccount.layer.cornerRadius = 48.0
        txt_MailID.attributedPlaceholder = NSAttributedString(string: "Mail ID", attributes: [.foregroundColor: UIColor.white])
        txt_FullName.attributedPlaceholder = NSAttributedString(string: "Full Name", attributes: [.foregroundColor: UIColor.white])
        txt_Password.attributedPlaceholder = NSAttributedString(string: "Password", attributes: [.foregroundColor: UIColor.white])
    }
    
    @IBAction func btn_CreateAccount(_ sender: UIButton) {
    }
    
    @IBAction func btn_Login(_ sender: UIButton) {
    }
}
