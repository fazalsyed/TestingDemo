//
//  EntitiesVC.swift
//  LoginUI
//
//  Created by syed fazal abbas on 24/09/23.
//

import UIKit

class EntitiesVC: UIViewController {
    
    var ArrEntite : [EnterieDataModel] = []
    @IBOutlet var tblEntities: UITableView!
    override func viewDidLoad() {
        super.viewDidLoad()
        tblEntities.delegate = self
        tblEntities.dataSource = self
        registerXib()
        fetchData()
    }
    func registerXib() {
        tblEntities.register(UINib(nibName: "CellT_Employe", bundle: nil), forCellReuseIdentifier: "CellT_Employe")
    }
    func fetchData(){
        Service.shared.Entites { [weak self] (enterie, error) in
            if let error = error {
                print("Failed to fetch employees:", error)
                return
            }
            
            if let employees = enterie {
                self?.ArrEntite = employees.entries
                DispatchQueue.main.async {
                    self?.tblEntities.reloadData()
                }
            }
        }
    }
}
extension EntitiesVC : UITableViewDelegate,UITableViewDataSource{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return ArrEntite.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tblEntities.dequeueReusableCell(withIdentifier: "CellT_Employe") as! CellT_Employe
        cell.lbl_EmpName.text = ArrEntite[indexPath.row].API
        cell.lbl_EmpFather.text = ArrEntite[indexPath.row].Auth
        cell.lbl_Mother.text = ArrEntite[indexPath.row].Category
        cell.lbl_EmpBrother.text = ArrEntite[indexPath.row].Cors
        cell.lbl_EmpID.text = ArrEntite[indexPath.row].Description
        cell.lbl_EmpAddress.text = ArrEntite[indexPath.row].Link
        return cell
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 200
    }
    
}
