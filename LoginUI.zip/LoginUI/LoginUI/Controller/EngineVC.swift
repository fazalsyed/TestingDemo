//
//  EngineVC.swift
//  LoginUI
//
//  Created by syed fazal abbas on 26/09/23.
//

import UIKit

class EngineVC: UIViewController {

    var ArrEngine : [EngineModel]?
    @IBOutlet var lblEngine: UITableView!
    override func viewDidLoad() {
        super.viewDidLoad()
        lblEngine.dataSource = self
        lblEngine.delegate = self
        registerXib()
        fetchData()
    }
    func registerXib() {
        lblEngine.register(UINib(nibName: "CellT_Employe", bundle: nil), forCellReuseIdentifier: "CellT_Employe")
    }
    func fetchData(){
        Service.shared.engine { [weak self] (enterie, error) in
            if let error = error {
                print("Failed to fetch employees:", error)
                return
            }
            
            if let employees = enterie {
                self?.ArrEngine = employees
                DispatchQueue.main.async {
                    self?.lblEngine.reloadData()
                }
            }
        }
    }
}
extension EngineVC : UITableViewDelegate,UITableViewDataSource{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return ArrEngine?.count ?? 0
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = lblEngine.dequeueReusableCell(withIdentifier: "CellT_Employe") as! CellT_Employe
        cell.lbl_EmpName.text = "\(ArrEngine?[indexPath.row].browser_family ?? "Default Value")"
        cell.lbl_EmpFather.text = ArrEngine?[indexPath.row].os_family
        cell.lbl_Mother.text = "\(ArrEngine?[indexPath.row].client.name ?? "Default Value")"
        cell.lbl_EmpBrother.text = "\(ArrEngine?[indexPath.row].device.brand ?? "Default Value")"
        cell.lbl_EmpID.text = "\(ArrEngine?[indexPath.row].os.version ?? "Default Value")"
        cell.lbl_EmpAddress.text = "\(ArrEngine?[indexPath.row].client.engine ?? "Default Value")"
        return cell
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 200
    }
}

