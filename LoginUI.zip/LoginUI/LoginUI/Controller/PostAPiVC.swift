//
//  PostAPiVC.swift
//  LoginUI
//
//  Created by syed fazal abbas on 07/11/23.
//

import UIKit

class PostAPiVC: UIViewController {
    
    @IBOutlet var txtBody: UITextField!
    @IBOutlet var txtTittle: UITextField!
    @IBOutlet var txtUserID: UITextField!
    override func viewDidLoad() {
        super.viewDidLoad()
        
        
    }
    
    @IBAction func btn_TappedPost(_ sender: UIButton) {
        self.createUser()
    }
}
extension PostAPiVC{
    func createUser() {
        guard let txtBody = txtBody.text, let txtTittle = txtTittle.text, let txtUserID = txtUserID.text else {
            return
        }
        
        let urlString = "https://gorest.co.in/public/v2/users"
        
        if let url = URL(string: urlString) {
            var request = URLRequest(url: url)
            
            request.httpMethod = "POST"
            // Define the request body as a dictionary
            let requestBody: [String: Any] = [
                "name": txtUserID,
                "email": txtTittle,
                "gender": txtBody
            ]
            request.httpBody = requestBody.percentEscaped().data(using: .utf8)
            // Convert the request body to JSON data
            do {
                let requestData = try JSONSerialization.data(withJSONObject: requestBody)
                request.httpBody = requestData
            } catch {
                print("Error encoding request body: \(error)")
                return
            }
            
            URLSession.shared.dataTask(with: request) { (data, response, error) in
                guard let data = data else {
                    if error == nil {
                        print(error?.localizedDescription ?? "Unknown Error")
                    }
                    return
                }
                
                if let response = response as? HTTPURLResponse {
                    guard (200 ... 299) ~= response.statusCode else {
                        print("Status code: \(response.statusCode)")
                        print(response)
                        return
                    }
                }
                
                do {
                    let json = try JSONSerialization.jsonObject(with: data, options: [])
                    print("Response: \(json)")
                } catch let error {
                    print(error.localizedDescription)
                }
            }.resume()
        }
    }
}
extension Dictionary {
    func percentEscaped() -> String {
        return map { (key, value) in
            let escapedKey = "\(key)".addingPercentEncoding(withAllowedCharacters: .urlQueryValueAllowed) ?? ""
            let escapedValue = "\(value)".addingPercentEncoding(withAllowedCharacters: .urlQueryValueAllowed) ?? ""
            return escapedKey + "=" + escapedValue
        }
        .joined(separator: "&")
    }
}

extension CharacterSet {
    static let urlQueryValueAllowed: CharacterSet = {
        let generalDelimitersToEncode = ":#[]@" // does not include "?" or "/" due to RFC 3986 - Section 3.4
        let subDelimitersToEncode = "!$&'()*+,;="
        
        var allowed = CharacterSet.urlQueryAllowed
        allowed.remove(charactersIn: "\(generalDelimitersToEncode)\(subDelimitersToEncode)")
        return allowed
    }()
}
