//
//  SignUpVC.swift
//  LoginUI
//
//  Created by syed fazal abbas on 16/09/23.
//

import UIKit

class SignUpVC: UIViewController {
    
    
    @IBOutlet var btnEye: UIButton!
    @IBOutlet var btnSignUp: UIButton!
    @IBOutlet var vwMain: UIView!
    override func viewDidLoad() {
        super.viewDidLoad()
        setupUI()
    }
    func setupUI(){
        btnSignUp.layer.cornerRadius = 10.0
        vwMain.roundCorners(corners: [.topLeft], radius: 35.0)
    }
    
    
    @IBAction func btnTappedEye(_ sender: UIButton) {
        btnEye.isSelected.toggle()
        if  btnEye.isSelected {
            btnEye.setImage(UIImage(named: "ic_eye"), for: .normal)
        } else {
            btnEye.setImage(UIImage(named: "ic_hiddeneye"), for: .normal)
        }
    }
}

