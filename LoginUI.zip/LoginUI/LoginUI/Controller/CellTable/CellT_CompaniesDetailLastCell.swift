//
//  CellT_CompaniesDetailLastCell.swift
//  LoginUI
//
//  Created by syed fazal abbas on 22/09/23.
//

import UIKit

class CellT_CompaniesDetailLastCell: UITableViewCell {
    @IBOutlet var img_MoreCompanies: UIImageView!
    @IBOutlet var img_MoveToNext: UIImageView!
    @IBOutlet var lbl_MoreCompanies: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
}
