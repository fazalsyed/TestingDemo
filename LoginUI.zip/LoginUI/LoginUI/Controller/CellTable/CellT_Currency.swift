//
//  CellT_Currency.swift
//  LoginUI
//
//  Created by syed fazal abbas on 02/10/23.
//

import UIKit

class CellT_Currency: UITableViewCell {

    @IBOutlet var lbl_Currency: UILabel!
    @IBOutlet var lbl_CurrencyCountry: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
}
