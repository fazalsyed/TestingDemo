//
//  CellT_CompaniesDetail.swift
//  LoginUI
//
//  Created by syed fazal abbas on 22/09/23.
//

import UIKit

class CellT_CompaniesDetail: UITableViewCell {

    @IBOutlet var img_Company: UIImageView!
    @IBOutlet var btn_Follow: UIButton!
    @IBOutlet var lbl_CompanyName: UILabel!
    @IBOutlet var lbl_CountFollower: UILabel!
    @IBOutlet var lbl_NewContent: UILabel!
    @IBOutlet var lbl_CompanyDesc: UILabel!
    @IBOutlet var vwChild: UIView!
    @IBOutlet var lbl_ListOfCompany: UILabel!
    @IBOutlet var vwChildHeightConstraint: NSLayoutConstraint!
    @IBOutlet var lbl_ListOfCompanyHeightConstraint: NSLayoutConstraint!
    @IBOutlet var lbl_NewContentWidthConstraint: NSLayoutConstraint!
   
    @IBOutlet var vw_LastCellHeightConstraint: NSLayoutConstraint!
    @IBOutlet var vw_LastCell: UIView!
    @IBOutlet var lbl_NextCompanyDetail: UILabel!
    @IBOutlet var img_NextArrow: UIImageView!
    @IBOutlet var img_stackoverflow: UIImageView!
    //Mark Height Constarint
    @IBOutlet var btn_FolloweHeightContraint: NSLayoutConstraint!
    @IBOutlet var img_CompanyHeightContraint: NSLayoutConstraint!
    
    override func awakeFromNib() {
        super.awakeFromNib()
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
    }
    //Mark : This Function is used to hide checkout these companies expect index 0.
    func  HideTopView(){
        lbl_ListOfCompanyHeightConstraint.constant = 0
        vwChildHeightConstraint.constant = 0
    }
    //Mark : This Function is used to show checkout these companies for index 1.
    func  ShowTopView(){
        lbl_ListOfCompanyHeightConstraint.constant = 54.0
        vwChildHeightConstraint.constant = 54.0
    }
}

