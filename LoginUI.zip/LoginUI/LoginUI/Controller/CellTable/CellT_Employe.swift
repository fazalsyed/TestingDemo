//
//  CellT_Employe.swift
//  LoginUI
//
//  Created by syed fazal abbas on 24/09/23.
//

import UIKit

class CellT_Employe: UITableViewCell {

    @IBOutlet var lbl_EmpName: UILabel!
    @IBOutlet var lbl_Mother: UILabel!
    @IBOutlet var lbl_EmpAddress: UILabel!
    @IBOutlet var lbl_EmpID: UILabel!
    @IBOutlet var lbl_EmpBrother: UILabel!
    @IBOutlet var lbl_EmpFather: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
}
