//
//  MarketVC.swift
//  LoginUI
//
//  Created by syed fazal abbas on 07/10/23.
//

import UIKit

class MarketVC: UIViewController {

    var ArrMarket : [MarketModel] = []
    @IBOutlet var tblMarket: UITableView!
    override func viewDidLoad() {
        super.viewDidLoad()
        tblMarket.delegate = self
        tblMarket.dataSource = self
        registerXib()
        fetchdata()
    }
    func registerXib() {
        tblMarket.register(UINib(nibName: "CellT_Employe", bundle: nil), forCellReuseIdentifier: "CellT_Employe")
    }
    func fetchdata(){
        Service.shared.market { [weak self] (result : Result <[MarketModel],Error>) in
            switch result {
            case .success(let success):
                self?.ArrMarket = success
                DispatchQueue.main.sync {
                    self?.tblMarket.reloadData()
                }
            case .failure(let failure):
                print("Data Not fetched :",failure)
            }
        }
    }
   
    
}
extension MarketVC : UITableViewDelegate,UITableViewDataSource{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return ArrMarket.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tblMarket.dequeueReusableCell(withIdentifier: "CellT_Employe") as! CellT_Employe
        cell.lbl_EmpName.text = "\(ArrMarket[indexPath.row].exchange)"
        cell.lbl_EmpFather.text = ArrMarket[indexPath.row].pair
        cell.lbl_Mother.text = "\(ArrMarket[indexPath.row].pairPrice)"
        cell.lbl_EmpBrother.text = "\(ArrMarket[indexPath.row].volume)"
        cell.lbl_EmpID.text = "\(ArrMarket[indexPath.row].price)"
        cell.lbl_EmpAddress.text = "\(ArrMarket[indexPath.row].price)"
        return cell
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 200
    }
}
