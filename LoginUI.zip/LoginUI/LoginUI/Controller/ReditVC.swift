//
//  ReditVC.swift
//  LoginUI
//
//  Created by syed fazal abbas on 04/10/23.
//

import UIKit

class ReditVC: UIViewController {

    var ArrRedit : [reditModel]? = []
    @IBOutlet var tblRedit: UITableView!
    override func viewDidLoad() {
        super.viewDidLoad()
        tblRedit.delegate = self
        tblRedit.dataSource = self
        registerXib()
        fetchData()
    }
    func registerXib() {
        tblRedit.register(UINib(nibName: "CellT_Employe", bundle: nil), forCellReuseIdentifier: "CellT_Employe")
    }
    func fetchData() {
        Service.shared.redit { [weak self] (result: Result<[reditModel], Error>) in
            switch result {
            case .success(let enterie):
                self?.ArrRedit = enterie
                DispatchQueue.main.async {
                    self?.tblRedit.reloadData()
                }
            case .failure(let error):
                print("Failed to fetch employees:", error)
            }
        }
    }
}
extension ReditVC : UITableViewDelegate,UITableViewDataSource{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return ArrRedit?.count ?? 0
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tblRedit.dequeueReusableCell(withIdentifier: "CellT_Employe") as! CellT_Employe
        cell.lbl_EmpName.text = "\(ArrRedit?[indexPath.row].sentiment ?? "Default Value")"
        cell.lbl_EmpFather.text = ArrRedit?[indexPath.row].ticker
        cell.lbl_Mother.text = "\(ArrRedit?[indexPath.row].no_of_comments ?? 0)"
        cell.lbl_EmpBrother.text = "\(ArrRedit?[indexPath.row].sentiment_score ?? 0)"
        cell.lbl_EmpID.text = "\(ArrRedit?[indexPath.row].no_of_comments ?? 0)"
        cell.lbl_EmpAddress.text = "\(ArrRedit?[indexPath.row].sentiment ?? "Default Value")"
        return cell
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 200
    }
}

