import UIKit

class CartVC: UIViewController {
    
    var ArrCart: [CartModel]?// Change the data type to [ProductData]
    
    
    @IBOutlet var tblCart: UITableView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
//        tblCart.delegate = self
//        tblCart.dataSource = self
//        registerXib()
       // fetchData()
    }
    
    func registerXib() {
        tblCart.register(UINib(nibName: "CellT_Employe", bundle: nil), forCellReuseIdentifier: "CellT_Employe")
    }
    
//    fileprivate func fetchData() {
//        Service.shared.cart { [weak self] (Result <[ProductData], Error>) in
//            <#code#>
//        }
//           
//    }
}

//extension CartVC: UITableViewDelegate, UITableViewDataSource {
//    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
//        return ArrCart?.count ?? 0
//    }
//    
//    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
//        let cell = tblCart.dequeueReusableCell(withIdentifier: "CellT_Employe") as! CellT_Employe
//        let productData = ArrCart?[indexPath.row]
//        // Configure the cell with productData properties
//        cell.lbl_EmpName.text = "Product ID: \(productData?.productId ?? 0)"
//        cell.lbl_EmpFather.text = "Quantity: \(productData?.quantity ?? 0)"
//        // Add any other properties you want to display
//        return cell
//    }
//    
//    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
//        return 200
//    }
//}
//
