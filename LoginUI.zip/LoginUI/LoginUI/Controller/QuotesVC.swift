//
//  QuotesVC.swift
//  LoginUI
//
//  Created by syed fazal abbas on 08/10/23.
//

import UIKit

class QuotesVC: UIViewController {

    var ArrQuotes : [assetModel]? = []
    @IBOutlet var tblQuotes: UITableView!
    override func viewDidLoad() {
        super.viewDidLoad()
        tblQuotes.delegate = self
        tblQuotes.dataSource = self
        registerXib()
        fetchdata()
    }
    func registerXib() {
        tblQuotes.register(UINib(nibName: "CellT_Employe", bundle: nil), forCellReuseIdentifier: "CellT_Employe")
    }
    func fetchdata(){
        Service.shared.QuoteAsset { [weak self] (result : Result <[assetModel],Error>) in
            switch result {
            case .success(let success):
                self?.ArrQuotes? = success
                DispatchQueue.main.sync {
                    self?.tblQuotes.reloadData()
                }
            case .failure(let failure):
                print("Data Not Fetched,",failure)
            }
        }
    }
}
extension QuotesVC : UITableViewDelegate,UITableViewDataSource{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return ArrQuotes?.count ?? 0
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tblQuotes.dequeueReusableCell(withIdentifier: "CellT_Employe") as! CellT_Employe
        cell.lbl_EmpName.text = ArrQuotes?[indexPath.row].openPrice
        cell.lbl_Mother.text = ArrQuotes?[indexPath.row].baseAsset
        cell.lbl_EmpBrother.text = ArrQuotes?[indexPath.row].bidPrice
        cell.lbl_EmpID.text = ArrQuotes?[indexPath.row].lastPrice
        cell.lbl_EmpAddress.text = ArrQuotes?[indexPath.row].askPrice
        return cell
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 200
    }
}
