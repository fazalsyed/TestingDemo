//
//  GrabVC.swift
//  LoginUI
//
//  Created by syed fazal abbas on 08/10/23.
//

import UIKit

class GrabVC: UIViewController {
    
    var ArrGrab : [GrabModel] = []
    @IBOutlet var tblGrab: UITableView!
    override func viewDidLoad() {
        super.viewDidLoad()
        tblGrab.delegate = self
        tblGrab.dataSource = self
        registerXib()
        fetchdata()
    }
    func registerXib() {
        tblGrab.register(UINib(nibName: "CellT_Employe", bundle: nil), forCellReuseIdentifier: "CellT_Employe")
    }
    func fetchdata(){
        Service.shared.grab { [weak self] (result : Result <GrabModel,Error>) in
            switch result {
            case .success(let success):
                self?.ArrGrab.append(success)
                DispatchQueue.main.sync {
                    self?.tblGrab.reloadData()
                }
                print("Data fetched successfully:", success)
            case .failure(let failure):
                print("Data Not Fetched:", failure)
            }
        }
    }
    
}
extension GrabVC : UITableViewDelegate,UITableViewDataSource{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return ArrGrab.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tblGrab.dequeueReusableCell(withIdentifier: "CellT_Employe") as! CellT_Employe
        cell.lbl_EmpName.text = ArrGrab[indexPath.row].icons.first?.src
        cell.lbl_Mother.text = ArrGrab[indexPath.row].icons.first?.sizes
        cell.lbl_EmpBrother.text = ArrGrab[indexPath.row].domain
        cell.lbl_EmpID.text = "\(ArrGrab[indexPath.row].icons.first?.type)"
        cell.lbl_EmpAddress.text = "\(ArrGrab[indexPath.row].icons.first?.src)"
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 200
    }
}
