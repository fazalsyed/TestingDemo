//
//  TelePortModelVC.swift
//  LoginUI
//
//  Created by syed fazal abbas on 18/11/23.
//

import UIKit

class TelePortModelVC: UIViewController {

    var ArrTele : [TelePortModel] = []
    @IBOutlet var tbl_TelePort: UITableView!
    override func viewDidLoad() {
        super.viewDidLoad()
        ApiCall()
        registerXib()
    }

    func registerXib() {
        tbl_TelePort.register(UINib(nibName: "CellT_Employe", bundle: nil), forCellReuseIdentifier: "CellT_Employe")
    }
    func ApiCall(){
        Service.shared.TelePort { [weak self] (result : Result<TelePortModel,Error>)  in
            switch result {
            case .success(let success):
                self?.ArrTele.append(success)
                DispatchQueue.main.async {
                    self?.tbl_TelePort.reloadData()
                }
            case .failure(let failure):
                print("Data Not Fetched \(failure)")
            }
        }
    }
}
//Marks: UITableViewDelgate & UITableViewDataSource
extension TelePortModelVC : UITableViewDelegate,UITableViewDataSource{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return ArrTele.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tbl_TelePort.dequeueReusableCell(withIdentifier: "CellT_Employe") as! CellT_Employe
        cell.lbl_EmpName.text = ArrTele[indexPath.row]._links.curies[indexPath.section].href
        cell.lbl_Mother.text = ArrTele[indexPath.row].summary
        cell.lbl_EmpBrother.text = ArrTele[indexPath.row].categories[indexPath.section].name
        cell.lbl_EmpID.text = "\(ArrTele[indexPath.row].teleport_city_score)"
        cell.lbl_EmpAddress.text = ArrTele[indexPath.row].categories[indexPath.section].name
        return cell
    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 200
    }
}
