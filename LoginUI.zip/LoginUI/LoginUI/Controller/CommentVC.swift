//
//  CommentVC.swift
//  LoginUI
//
//  Created by syed fazal abbas on 24/09/23.
//

import UIKit

class CommentVC: UIViewController {
    
    
    var ArrComment : [CommentModel]?
    @IBOutlet var tblComment: UITableView!
    override func viewDidLoad() {
        super.viewDidLoad()
        tblComment.delegate = self
        tblComment.dataSource = self
        registerXib()
        fetchData()
    }
    func registerXib() {
        tblComment.register(UINib(nibName: "CellT_Employe", bundle: nil), forCellReuseIdentifier: "CellT_Employe")
    }
    fileprivate func fetchData() {
        Service.shared.Comment {[weak self] (commentList, err) in
            if let err = err {
                print("Failed to fetch courses:", err)
                return
            }
            self?.ArrComment = commentList
            if let _ = self?.ArrComment{
                self?.tblComment.reloadData()
            }
        }
    }
}
//Marks : UitableViewDelegat & UitableViewDataSource
extension CommentVC : UITableViewDelegate,UITableViewDataSource{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return ArrComment?.count ?? 0
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tblComment.dequeueReusableCell(withIdentifier: "CellT_Employe") as! CellT_Employe
        // Configure the cell with productData properties
        cell.lbl_EmpName.text = ArrComment?[indexPath.row].name
        cell.lbl_EmpFather.text = ArrComment?[indexPath.row].email
        cell.lbl_EmpBrother.text = ArrComment?[indexPath.row].body
        cell.lbl_Mother.text =   "\(ArrComment?[indexPath.row].postId ?? 0 )"
        cell.lbl_EmpAddress.text = "\(ArrComment?[indexPath.row].id ?? 0)"
        // Add any other properties you want to display
        return cell
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 200
    }
    
}
