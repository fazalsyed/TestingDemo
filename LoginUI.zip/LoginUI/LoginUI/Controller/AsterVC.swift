//
//  AsterVC.swift
//  LoginUI
//
//  Created by syed fazal abbas on 18/11/23.
//

import UIKit

class AsterVC: UIViewController {

    var ArrAster : [asterModel] = []
    @IBOutlet var tbl_Aster: UITableView!
    override func viewDidLoad() {
        super.viewDidLoad()
        ApiCall()
        registerXib()
    }
    func registerXib() {
        tbl_Aster.register(UINib(nibName: "CellT_Employe", bundle: nil), forCellReuseIdentifier: "CellT_Employe")
    }
    func ApiCall(){
        Service.shared.aster { [weak self] (result : Result<[asterModel],Error>) in
            switch result {
            case .success(let success):
                self?.ArrAster = success
                DispatchQueue.main.async {
                    self?.tbl_Aster.reloadData()
                }
            case .failure(let failure):
                print("Data Not Fetched \(failure)")
            }
        }
    }
}
//Marks: UITableViewDelgate & UITableViewDataSource
extension AsterVC : UITableViewDelegate,UITableViewDataSource{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return ArrAster.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tbl_Aster.dequeueReusableCell(withIdentifier: "CellT_Employe") as! CellT_Employe
        cell.lbl_EmpName.text = ArrAster[indexPath.row].results[indexPath.section].key
        cell.lbl_Mother.text = ArrAster[indexPath.row].results[indexPath.section].obs_id
        cell.lbl_EmpBrother.text = ArrAster[indexPath.row].results[indexPath.section].pos_err_ang
        
        cell.lbl_EmpID.text = ArrAster[indexPath.row].results[indexPath.section].obs_id
        cell.lbl_EmpAddress.text = "\(ArrAster[indexPath.row].results[indexPath.section].pixel_loc_x)"
        return cell
    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 200
    }
}
