//
//  TicketApiVC.swift
//  LoginUI
//
//  Created by syed fazal abbas on 07/10/23.
//

import UIKit

class TicketApiVC: UIViewController {

    var ArrTicket : [ticketApiModel] = []
    @IBOutlet var tblTicket: UITableView!
    override func viewDidLoad() {
        super.viewDidLoad()
        tblTicket.delegate = self
        tblTicket.dataSource = self
        registerXib()
        fetchdata()
    }
    func registerXib() {
        tblTicket.register(UINib(nibName: "CellT_Employe", bundle: nil), forCellReuseIdentifier: "CellT_Employe")
    }
    func fetchdata (){
        Service.shared.ticketApi { [weak self] (result : Result <ticketApiModel,Error>) in
            switch result {
            case .success(let success):
                self?.ArrTicket.append(success)
                DispatchQueue.main.sync {
                    self?.tblTicket.reloadData()
                }
            case .failure(let failure):
                print("Data Not Fetched:",failure)
            }
        }
    }
    
}
extension TicketApiVC : UITableViewDelegate,UITableViewDataSource{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return ArrTicket.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tblTicket.dequeueReusableCell(withIdentifier: "CellT_Employe") as! CellT_Employe
        cell.lbl_EmpName.text = "\(ArrTicket[indexPath.row].data.first?.tsupply)"
        cell.lbl_EmpFather.text = ArrTicket[indexPath.row].data.first?.msupply
        cell.lbl_Mother.text = "\(ArrTicket[indexPath.row].data.first?.volume24)"
        cell.lbl_EmpBrother.text = "\(ArrTicket[indexPath.row].data.first?.name)"
        cell.lbl_EmpID.text = "\(ArrTicket[indexPath.row].data.first?.percentChange24H)"
        cell.lbl_EmpAddress.text = "\(ArrTicket[indexPath.row].data.first?.percentChange7D)"
        return cell
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 200
    }
}


