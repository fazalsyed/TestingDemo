//
//  ViewController.swift
//  LoginUI
//
//  Created by syed fazal abbas on 14/09/23.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet var txt_MailID: UITextField!
    @IBOutlet var txt_Password: UITextField!
    @IBOutlet var btn_Login: UIButton!
    @IBOutlet var vwBackGround: UIView!
    @IBOutlet var vwBackGrounds: UIView!
    override func viewDidLoad() {
        super.viewDidLoad()
       setUpUI()
        
    }
//Mark : UISetup
    func setUpUI(){
        btn_Login.layer.cornerRadius = 26.0
        vwBackGrounds.layer.cornerRadius = 48.0
        vwBackGround.layer.borderWidth = 3
        vwBackGround.layer.cornerRadius = 3
        vwBackGround.layer.borderColor = UIColor.white.cgColor
        vwBackGrounds.layer.borderColor = UIColor.clear.cgColor
      txt_MailID.attributedPlaceholder = NSAttributedString(string: "Mail ID", attributes: [.foregroundColor: UIColor.white])
        txt_Password.attributedPlaceholder = NSAttributedString(string: "Password", attributes: [.foregroundColor: UIColor.white])
    }
    
    @IBAction func btn_TappedForgetPassword(_ sender: UIButton) {
    }
    
    @IBAction func btn_TappedLogin(_ sender: UIButton) {
    }
    
    @IBAction func btn_CreateAccount(_ sender: UIButton) {
        let vc = self.storyboard?.instantiateViewController(withIdentifier: "CreateAccountVC") as? CreateAccountVC
        self.navigationController?.pushViewController(vc!, animated: true)
    }
}

