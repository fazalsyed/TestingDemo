//
//  urlVC.swift
//  LoginUI
//
//  Created by syed fazal abbas on 25/09/23.
//

import UIKit

class urlVC: UIViewController {

    var ArrUrl : [urlDataModel]? = []
    @IBOutlet var tblUrl: UITableView!
    override func viewDidLoad() {
        super.viewDidLoad()
        tblUrl.delegate = self
        tblUrl.dataSource = self
        registerXib()
        fetchData()
    }
    func registerXib() {
        tblUrl.register(UINib(nibName: "CellT_Employe", bundle: nil), forCellReuseIdentifier: "CellT_Employe")
    }
    func fetchData(){
        Service.shared.url { [weak self] (enterie, error) in
            if let error = error {
                print("Failed to fetch employees:", error)
                return
            }
            
            if let employees = enterie {
                self?.ArrUrl = employees.urls
                DispatchQueue.main.async {
                    self?.tblUrl.reloadData()
                }
            }
        }
    }
    }
    extension urlVC : UITableViewDelegate,UITableViewDataSource{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return ArrUrl?.count ?? 0
    }

    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tblUrl.dequeueReusableCell(withIdentifier: "CellT_Employe") as! CellT_Employe
        cell.lbl_EmpName.text = "\(ArrUrl?[indexPath.row].url)"
        cell.lbl_EmpFather.text = ArrUrl?[indexPath.row].url_status
        cell.lbl_Mother.text = ArrUrl?[indexPath.row].date_added
        cell.lbl_EmpBrother.text = ArrUrl?[indexPath.row].host
        cell.lbl_EmpID.text = ArrUrl?[indexPath.row].blacklists.spamhaus_dbl
        cell.lbl_EmpAddress.text = ArrUrl?[indexPath.row].tags.tags
        return cell
    }

    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 200
    }

    }


