//
//  BrewVC.swift
//  LoginUI
//
//  Created by syed fazal abbas on 25/09/23.
//

import UIKit

class BrewVC: UIViewController {
    
    var Arrbre : [breModel]? 
    @IBOutlet var tblbrew: UITableView!
    override func viewDidLoad() {
        super.viewDidLoad()
        tblbrew.delegate = self
        tblbrew.dataSource = self
        registerXib()
        fetchData()
    }
    func registerXib() {
        tblbrew.register(UINib(nibName: "CellT_Employe", bundle: nil), forCellReuseIdentifier: "CellT_Employe")
    }
    func fetchData(){
        Service.shared.bre { [weak self] (enterie, error) in
            if let error = error {
                print("Failed to fetch employees:", error)
                return
            }
            
            if let employees = enterie {
                self?.Arrbre = employees
                DispatchQueue.main.async {
                    self?.tblbrew.reloadData()
                }
            }
        }
    }
    }
    extension BrewVC : UITableViewDelegate,UITableViewDataSource{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return Arrbre?.count ?? 0
    }

    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tblbrew.dequeueReusableCell(withIdentifier: "CellT_Employe") as! CellT_Employe
        cell.lbl_EmpName.text = Arrbre?[indexPath.row].id
        cell.lbl_EmpFather.text = Arrbre?[indexPath.row].longitude
        cell.lbl_Mother.text = Arrbre?[indexPath.row].stateProvince
        cell.lbl_EmpBrother.text = Arrbre?[indexPath.row].postalCode
        cell.lbl_EmpID.text = Arrbre?[indexPath.row].address3
        cell.lbl_EmpAddress.text = Arrbre?[indexPath.row].breweryType
        return cell
    }

    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 200
    }

    }

