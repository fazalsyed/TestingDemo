//
//  ProductVC.swift
//  LoginUI
//
//  Created by syed fazal abbas on 24/09/23.
//

import UIKit

class ProductVC: UIViewController {
    
    var ArrProduct: [ProductModel] = []
    @IBOutlet var tblProduct: UITableView!
    override func viewDidLoad() {
        super.viewDidLoad()
        tblProduct.delegate = self
        tblProduct.dataSource = self
        registerXib()
        fetchData()
    }
    func registerXib(){
        tblProduct.register(UINib(nibName: "CellT_Employe", bundle: nil), forCellReuseIdentifier: "CellT_Employe")
    }
    func fetchData() {
        Service.shared.product { [weak self] (result : Result<[ProductModel], Error>) in
            switch result {
            case .success(let success):
                self?.ArrProduct = success
                DispatchQueue.main.async {
                    self?.tblProduct.reloadData()
                }
            case .failure(let failure):
                print("Data NOt Fetched \(failure)")
            }
        }
    }
}
extension ProductVC : UITableViewDelegate,UITableViewDataSource{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return ArrProduct.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tblProduct.dequeueReusableCell(withIdentifier: "CellT_Employe") as! CellT_Employe
        cell.lbl_EmpName.text = ArrProduct[indexPath.row].title
        cell.lbl_EmpFather.text = ArrProduct[indexPath.row].category
        //cell.lbl_Mother.text = ArrProduct[indexPath.row].description
        cell.lbl_EmpBrother.text = ArrProduct[indexPath.row].image
        cell.lbl_EmpID.text =  "\(ArrProduct[indexPath.row].price)"
        cell.lbl_Mother.text =  "\(ArrProduct[indexPath.row].rating.count)"
        return cell
    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 200
    }
    
}
