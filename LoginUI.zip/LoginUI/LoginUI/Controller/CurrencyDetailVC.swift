//
//  CurrencyDetailVC.swift
//  LoginUI
//
//  Created by syed fazal abbas on 07/10/23.
//

import UIKit

class CurrencyDetailVC: UIViewController {

    var ArrCurrency : [currentPrice] = []
    @IBOutlet var tblCurrency: UITableView!
    override func viewDidLoad() {
        super.viewDidLoad()
        tblCurrency.delegate = self
        tblCurrency.dataSource = self
        registerXib()
        fetchdata()
    }
    func registerXib() {
        tblCurrency.register(UINib(nibName: "CellT_Employe", bundle: nil), forCellReuseIdentifier: "CellT_Employe")
    }
    func fetchdata(){
        Service.shared.currency { [weak self] (result : Result<currentPrice,Error>) in
            switch result {
            case .success(let success):
                self?.ArrCurrency.append(success)
                DispatchQueue.main.sync {
                    self?.tblCurrency.reloadData()
                }
            case .failure(let failure):
                print("Failed to fetchdat :",failure)
            }
        }
    }
}
extension CurrencyDetailVC : UITableViewDelegate,UITableViewDataSource{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return ArrCurrency.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tblCurrency.dequeueReusableCell(withIdentifier: "CellT_Employe") as! CellT_Employe
        cell.lbl_EmpName.text = "\(ArrCurrency[indexPath.row].bpi)"
        cell.lbl_EmpFather.text = ArrCurrency[indexPath.row].chartName
        cell.lbl_Mother.text = "\(ArrCurrency[indexPath.row].disclaimer)"
        cell.lbl_EmpBrother.text = "\(ArrCurrency[indexPath.row].time.updated)"
        cell.lbl_EmpID.text = "\(ArrCurrency[indexPath.row].bpi.EUR.rate)"
        cell.lbl_EmpAddress.text = "\(ArrCurrency[indexPath.row].bpi.GBP.rate_float)"
        return cell
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 200
    }
}
