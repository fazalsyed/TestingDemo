//
//  ExchangeVC.swift
//  LoginUI
//
//  Created by syed fazal abbas on 07/10/23.
//

import UIKit

class ExchangeVC: UIViewController {
    
    var ArrExchange : [ExhageModel] = []
    @IBOutlet var tblExchange: UITableView!
    override func viewDidLoad() {
        super.viewDidLoad()
        tblExchange.delegate = self
        tblExchange.dataSource = self
        registerXib()
        fetchdata()
    }
    func registerXib() {
        tblExchange.register(UINib(nibName: "CellT_Employe", bundle: nil), forCellReuseIdentifier: "CellT_Employe")
    }
    func fetchdata(){
        Service.shared.exchange { [weak self] (result : Result<ExhageModel,Error>) in
            switch result {
            case .success(let success):
                self?.ArrExchange.append(success)
                DispatchQueue.main.sync {
                    self?.tblExchange.reloadData()
                }
            case .failure(let failure):
                print("Data Not Fetched:",failure)
            }
        }
    }
}
extension ExchangeVC : UITableViewDelegate,UITableViewDataSource{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return ArrExchange.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tblExchange.dequeueReusableCell(withIdentifier: "CellT_Employe") as! CellT_Employe
        cell.lbl_EmpName.text = "\(ArrExchange[indexPath.row].error.code)"
        cell.lbl_EmpFather.text = ArrExchange[indexPath.row].error.info
        cell.lbl_Mother.text = "\(ArrExchange[indexPath.row].error.type)"
        cell.lbl_EmpBrother.text = "\(ArrExchange[indexPath.row].success)"
        cell.lbl_EmpID.text = "\(ArrExchange[indexPath.row].success)"
        cell.lbl_EmpAddress.text = "\(ArrExchange[indexPath.row].error.info)"
        return cell
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 200
    }
}
