//
//  MetasVC.swift
//  LoginUI
//
//  Created by syed fazal abbas on 28/10/23.
//

import UIKit

class MetasVC: UIViewController {
    
    var ArrMetas : [metasDataModel] = []
    @IBOutlet var tblMetas: UITableView!
    override func viewDidLoad() {
        super.viewDidLoad()
        tblMetas.dataSource = self
        tblMetas.delegate = self
        registerXib()
        Apicall()
        
    }
    func registerXib() {
        tblMetas.register(UINib(nibName: "CellT_Employe", bundle: nil), forCellReuseIdentifier: "CellT_Employe")
    }
    func Apicall(){
        Service.shared.metaData { [weak self] (result : Result<metasDataModel,Error>)in
            switch result {
            case .success(let success):
                self?.ArrMetas.append(success)
                DispatchQueue.main.async {
                    self?.tblMetas.reloadData()
                }
            case .failure(let failure):
                print("The Data Not Fetched \(failure)")
            }
        }
    }
}
//Marks: UITableViewDelgate & UITableViewDataSource
extension MetasVC : UITableViewDelegate,UITableViewDataSource{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return ArrMetas.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tblMetas.dequeueReusableCell(withIdentifier: "CellT_Employe") as! CellT_Employe
        cell.lbl_EmpName.text = ArrMetas[indexPath.row].stations[indexPath.section].device_id
        cell.lbl_Mother.text = ArrMetas[indexPath.row].stations[indexPath.section].id
        cell.lbl_EmpBrother.text = ArrMetas[indexPath.row].stations[indexPath.section].name
        cell.lbl_EmpID.text = "\(ArrMetas[indexPath.row].stations[indexPath.section].location.longitude)"
        cell.lbl_EmpAddress.text = "\(ArrMetas[indexPath.row].stations[indexPath.section].location.latitude)"
        return cell
    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 200
    }
}
