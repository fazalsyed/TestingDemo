//
//  MapsVC.swift
//  LoginUI
//
//  Created by syed fazal abbas on 28/10/23.
//

import UIKit

class MapsVC: UIViewController {

    var ArrMaps : [WelcomeElement] = []
    @IBOutlet var tblMaps: UITableView!
    override func viewDidLoad() {
        super.viewDidLoad()
        tblMaps.dataSource = self
        tblMaps.delegate = self
        registerXib()
        ApiCall()
        
    }
    func registerXib() {
        tblMaps.register(UINib(nibName: "CellT_Employe", bundle: nil), forCellReuseIdentifier: "CellT_Employe")
    }
    //Marks: API Call
    func ApiCall(){
        Service.shared.maps { [weak self] (result : Result<[WelcomeElement],Error>) in
            switch result {
            case .success(let success):
                self?.ArrMaps = success
                DispatchQueue.main.async {
                    self?.tblMaps.reloadData()
                }
                print("Data Fetched Succesfully")
            case .failure(let failure):
                print("Data NOt Fetched \(failure)")
            }
        }
    }
}
//Marks : UITableViewDelegates & UITableViewExtension
extension MapsVC  : UITableViewDelegate,UITableViewDataSource{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return ArrMaps.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tblMaps.dequeueReusableCell(withIdentifier: "CellT_Employe") as! CellT_Employe
        cell.lbl_EmpName.text = ArrMaps[indexPath.row].image
        cell.lbl_Mother.text = ArrMaps[indexPath.row].createdAt
        cell.lbl_EmpBrother.text = ArrMaps[indexPath.row].currentLocation.timestamp
        cell.lbl_EmpID.text = ArrMaps[indexPath.row].sensors[indexPath.section].lastMeasurement
        cell.lbl_EmpAddress.text = ArrMaps[indexPath.row].sensors[indexPath.section].unit
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 200
    }
    
}
