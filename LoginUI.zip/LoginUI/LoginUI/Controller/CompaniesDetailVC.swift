//
//  CompaniesDetailVC.swift
//  LoginUI
//
//  Created by syed fazal abbas on 22/09/23.
//

import UIKit

class CompaniesDetailVC: UIViewController {
    
    @IBOutlet var tblCompaniesDetail: UITableView!
    var shouldHideChildViews = false
    override func viewDidLoad() {
        super.viewDidLoad()
        tblCompaniesDetail.delegate = self
        tblCompaniesDetail.dataSource = self
        registerXibCell()
    }
    //Mark : Function is To Load Xib.
    func registerXibCell(){
        tblCompaniesDetail.register(UINib(nibName:"CellT_CompaniesDetail" , bundle: nil), forCellReuseIdentifier: "CellT_CompaniesDetail")
        tblCompaniesDetail.register(UINib(nibName: "CellT_CompaniesDetailLastCell" , bundle: nil), forCellReuseIdentifier: "CellT_CompaniesDetailLastCell")
    }
}

//Mark : UItableViewDelegate & UITableVIewDataSource.
extension CompaniesDetailVC : UITableViewDelegate,UITableViewDataSource{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return DataModel.ArrCompany.count
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        if indexPath.row == 0 {
            let cell = tblCompaniesDetail.dequeueReusableCell(withIdentifier: "CellT_CompaniesDetail") as! CellT_CompaniesDetail
            cell.img_Company.image = UIImage(named: DataModel.ArrCompany[indexPath.row].img)
            cell.lbl_CompanyName.text = DataModel.ArrCompany[indexPath.row].companyName
            cell.lbl_CompanyDesc.text = DataModel.ArrCompany[indexPath.row].CompanyDesc
            cell.ShowTopView()
            if DataModel.ArrCompany[indexPath.row].NewContent.isEmpty {
                cell.lbl_NewContentWidthConstraint.constant = 0.0
                cell.lbl_CountFollower.text = DataModel.ArrCompany[indexPath.row].FolloweCount
            } else {
                cell.lbl_NewContentWidthConstraint.constant = 100
                cell.lbl_CountFollower.text = DataModel.ArrCompany[indexPath.row].FolloweCount
                cell.lbl_NewContent.text = DataModel.ArrCompany[indexPath.row].NewContent
            }
            return cell
        } else if indexPath.row == DataModel.ArrCompany.count - 1 {
            let cell = tblCompaniesDetail.dequeueReusableCell(withIdentifier: "CellT_CompaniesDetailLastCell") as! CellT_CompaniesDetailLastCell
            cell.lbl_MoreCompanies.text = "More Companies on Stack Overflow"
            return cell
        } else {
            let cell = tblCompaniesDetail.dequeueReusableCell(withIdentifier: "CellT_CompaniesDetail") as! CellT_CompaniesDetail
            cell.img_Company.image = UIImage(named: DataModel.ArrCompany[indexPath.row].img)
            cell.lbl_CompanyName.text = DataModel.ArrCompany[indexPath.row].companyName
            cell.lbl_CompanyDesc.text = DataModel.ArrCompany[indexPath.row].CompanyDesc
            cell.HideTopView()
            if DataModel.ArrCompany[indexPath.row].NewContent.isEmpty {
                cell.lbl_NewContentWidthConstraint.constant = 0.0
                cell.lbl_CountFollower.text = DataModel.ArrCompany[indexPath.row].FolloweCount
            } else {
                cell.lbl_NewContentWidthConstraint.constant = 100
                cell.lbl_CountFollower.text = DataModel.ArrCompany[indexPath.row].FolloweCount
                cell.lbl_NewContent.text = DataModel.ArrCompany[indexPath.row].NewContent
            }
            return cell
        }
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        if indexPath.row == tableView.numberOfRows(inSection: indexPath.section) - 1 {
                return 80.0
            } else {
                return UITableView.automaticDimension
            }
    }
}
