//
//  ActivityVC.swift
//  LoginUI
//
//  Created by syed fazal abbas on 26/09/23.
//

import UIKit

class ActivityVC: UIViewController {

    var ArrActivity : [activityModel]?
    @IBOutlet var tblActitvity: UITableView!
    override func viewDidLoad() {
        super.viewDidLoad()
        registerXib()
        fetchData()
    }
    func registerXib() {
        tblActitvity.register(UINib(nibName: "CellT_Employe", bundle: nil), forCellReuseIdentifier: "CellT_Employe")
    }
    func fetchData(){
        Service.shared.activity { [weak self] (enterie, error) in
            if let error = error {
                print("Failed to fetch employees:", error)
                return
            }
            
            if let employees = enterie {
                self?.ArrActivity = employees
                DispatchQueue.main.async {
                    self?.tblActitvity.reloadData()
                }
            }
        }
    }
}
extension ActivityVC : UITableViewDelegate,UITableViewDataSource{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return ArrActivity?.count ?? 0
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tblActitvity.dequeueReusableCell(withIdentifier: "CellT_Employe") as! CellT_Employe
        cell.lbl_EmpName.text = "\(ArrActivity?[indexPath.row].accessibility ?? 0)"
        cell.lbl_EmpFather.text = ArrActivity?[indexPath.row].key
        cell.lbl_Mother.text = "\(ArrActivity?[indexPath.row].activity ?? "Default Value")"
        cell.lbl_EmpBrother.text = "\(ArrActivity?[indexPath.row].participants ?? 0.0)"
        cell.lbl_EmpID.text = "\(ArrActivity?[indexPath.row].price ?? 0.0)"
        cell.lbl_EmpAddress.text = "\(ArrActivity?[indexPath.row].type ?? "Default Value")"
        return cell
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 200
    }
    
}
