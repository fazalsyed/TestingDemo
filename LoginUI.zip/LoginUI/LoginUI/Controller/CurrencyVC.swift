//
//  CurrencyVC.swift
//  LoginUI
//
//  Created by syed fazal abbas on 02/10/23.
//

import UIKit

class CurrencyVC: UIViewController {
    
    var exchangeRates: [ExchangeRate] = []
    @IBOutlet var tblCurrency: UITableView!
    override func viewDidLoad() {
        super.viewDidLoad()
        tblCurrency.delegate = self
        tblCurrency.dataSource = self
        registerXib()
        fetchExchangeRates()
    }
    func registerXib() {
        tblCurrency.register(UINib(nibName: "CellT_Currency", bundle: nil), forCellReuseIdentifier: "CellT_Currency")
    }
    func fetchExchangeRates() {
        Service.shared.fetchExchangeRates { [weak self] result in
            DispatchQueue.main.async {
                switch result {
                case .success(let exchangeRateResponse):
                    self?.exchangeRates = exchangeRateResponse.rates.map { ExchangeRate(currencyCode: $0.key, rate: $0.value) }
                    self?.tblCurrency.reloadData()
                case .failure(let error):
                    print("Error fetching exchange rates: \(error)")
                }
            }
        }
    }
}
extension CurrencyVC : UITableViewDelegate,UITableViewDataSource{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return exchangeRates.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "CellT_Currency", for: indexPath) as! CellT_Currency
        let rate = exchangeRates[indexPath.row]
        cell.lbl_CurrencyCountry?.text = rate.currencyCode
        cell.lbl_Currency?.text = "\(rate.rate)"
        return cell
    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 80
    }
}
