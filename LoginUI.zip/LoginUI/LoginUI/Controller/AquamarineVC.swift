//
//  AquamarineVC.swift
//  LoginUI
//
//  Created by syed fazal abbas on 24/09/23.
//

import UIKit

class AquamarineVC: UIViewController {
    
    var ArrAqua : [Aqua] = []
    @IBOutlet var tblAquamarine: UITableView!
    override func viewDidLoad() {
        super.viewDidLoad()
        registerXib()
        fetchData()
    }
    
    func registerXib() {
        tblAquamarine.register(UINib(nibName: "CellT_Employe", bundle: nil), forCellReuseIdentifier: "CellT_Employe")
    }
    func fetchData(){
        Service.shared.aqua { [weak self] (enterie, error) in
            if let error = error {
                print("Failed to fetch employees:", error)
                return
            }
            
            if let employees = enterie {
                self?.ArrAqua = employees
                DispatchQueue.main.async {
                    self?.tblAquamarine.reloadData()
                }
            }
        }
    }
}
extension AquamarineVC : UITableViewDelegate,UITableViewDataSource{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return ArrAqua.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tblAquamarine.dequeueReusableCell(withIdentifier: "CellT_Employe") as! CellT_Employe
        cell.lbl_EmpName.text = ArrAqua[indexPath.row].base.keyword
        cell.lbl_EmpFather.text = ArrAqua[indexPath.row].base.rgb.value
        cell.lbl_Mother.text = "\(ArrAqua[indexPath.row].base.rgb.composition.green)"
        cell.lbl_EmpBrother.text = ArrAqua[indexPath.row].base.hex.composition.red
        cell.lbl_EmpID.text = ArrAqua[indexPath.row].base.hsl.value
        cell.lbl_EmpAddress.text =   "\(ArrAqua[indexPath.row].base.rgb.composition.green)"
        return cell
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 200
    }
    
}
