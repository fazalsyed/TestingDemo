//
//  LoginVC.swift
//  LoginUI
//
//  Created by syed fazal abbas on 15/09/23.
//

import UIKit
import MaterialComponents.MaterialTextControls_OutlinedTextFields


class LoginVC: UIViewController {

    @IBOutlet var vwMain: UIView!
    @IBOutlet var btnLogin: UIButton!
    @IBOutlet var txtEmailMobile: MDCOutlinedTextField!
    @IBOutlet var txtPassword: MDCOutlinedTextField!
    @IBOutlet var btnEye: UIButton!
    @IBOutlet var btnTicked: UIButton!
    var usernameController: MDCTextInputControllerOutlined?
    var passwordController: MDCTextInputControllerOutlined?



    override func viewDidLoad() {
        super.viewDidLoad()
//         usernameController = MDCTextInputControllerOutlined(textInput: txtEmailMobile)
//        passwordController = MDCTextInputControllerOutlined(textInput: txtPassword)
        txtEmailMobile.placeholder = "Email/Mobile"
        txtPassword.placeholder = "Password"
      UiUpdate()
    }
    func UiUpdate(){
        vwMain.roundCorners(corners: [.topLeft], radius: 35.0)
        btnLogin.layer.cornerRadius = 10.0
        btnTicked.layer.cornerRadius = 5.0
    }

    @IBAction func btnTappedTicked(_ sender: UIButton) {
        btnTicked.isSelected.toggle()
        if  btnTicked.isSelected {
            btnTicked.setImage(UIImage(named: "ic_checkbox"), for: .normal)
        } else {
            btnTicked.setImage(UIImage(named: "ic_unchecked"), for: .normal)
        }


    }
    @IBAction func btnClickedEye(_ sender: UIButton) {
        btnEye.isSelected.toggle()
        if  btnEye.isSelected {
            btnEye.setImage(UIImage(named: "ic_eye"), for: .normal)
        } else {
            btnEye.setImage(UIImage(named: "ic_hiddeneye"), for: .normal)
        }
    }


    @IBAction func btnTappedLogin(_ sender: UIButton) {
    }

    @IBAction func btnSignUp(_ sender: UIButton) {
        let vc = self.storyboard?.instantiateViewController(withIdentifier: "SignUpVC") as? SignUpVC
        self.navigationController?.pushViewController(vc!, animated: true)

    }
}

