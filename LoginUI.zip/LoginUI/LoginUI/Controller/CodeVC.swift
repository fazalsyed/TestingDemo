//
//  CodeVC.swift
//  LoginUI
//
//  Created by syed fazal abbas on 25/09/23.
//

import UIKit

class CodeVC: UIViewController {

    var ArrCode : [codeModel]? = []
    @IBOutlet var tblCode: UITableView!
    override func viewDidLoad() {
        super.viewDidLoad()
        tblCode.delegate = self
        tblCode.dataSource = self
        registerXib()
        fetchData()
    }
func registerXib() {
    tblCode.register(UINib(nibName: "CellT_Employe", bundle: nil), forCellReuseIdentifier: "CellT_Employe")
}
func fetchData(){
    Service.shared.code { [weak self] (enterie, error) in
        if let error = error {
            print("Failed to fetch employees:", error)
            return
        }
        
        if let employees = enterie {
            self?.ArrCode = employees
            DispatchQueue.main.async {
                self?.tblCode.reloadData()
            }
        }
    }
}
}
extension CodeVC : UITableViewDelegate,UITableViewDataSource{
func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
    return ArrCode?.count ?? 0
}

func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
    let cell = tblCode.dequeueReusableCell(withIdentifier: "CellT_Employe") as! CellT_Employe
    cell.lbl_EmpName.text = "\(ArrCode?[indexPath.row].result.short_link2)"
    cell.lbl_EmpFather.text = ArrCode?[indexPath.row].result.full_share_link
    cell.lbl_Mother.text = ArrCode?[indexPath.row].result.share_link
    cell.lbl_EmpBrother.text = ArrCode?[indexPath.row].result.original_link
    cell.lbl_EmpID.text = ArrCode?[indexPath.row].result.full_share_link
    cell.lbl_EmpAddress.text = ArrCode?[indexPath.row].result.short_link2
    return cell
}

func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
    return 200
}

}

