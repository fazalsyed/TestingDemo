//
//  TicketVC.swift
//  LoginUI
//
//  Created by syed fazal abbas on 26/09/23.
//

import UIKit

class TicketVC: UIViewController {
    
    var Arrtickte : [ticketModel]? = []
    @IBOutlet var tblTicket: UITableView!
    override func viewDidLoad() {
        super.viewDidLoad()
        tblTicket.delegate = self
        tblTicket.dataSource = self
        registerXib()
        fetchData()
    }
    func registerXib() {
        tblTicket.register(UINib(nibName: "CellT_Employe", bundle: nil), forCellReuseIdentifier: "CellT_Employe")
    }
    func fetchData(){
        Service.shared.ticket { [weak self] (enterie, error) in
            if let error = error {
                print("Failed to fetch employees:", error)
                return
            }
            
            if let employees = enterie {
                self?.Arrtickte = employees
                DispatchQueue.main.async {
                    self?.tblTicket.reloadData()
                }
            }
        }
    }
}
extension TicketVC : UITableViewDelegate,UITableViewDataSource{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return Arrtickte?.count ?? 0
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tblTicket.dequeueReusableCell(withIdentifier: "CellT_Employe") as! CellT_Employe
        cell.lbl_EmpName.text = "\(Arrtickte?[indexPath.row].askPrice ?? "Default Value")"
        cell.lbl_EmpFather.text = Arrtickte?[indexPath.row].baseAsset
        cell.lbl_Mother.text = "\(Arrtickte?[indexPath.row].bidPrice ?? "Default Value")"
        cell.lbl_EmpBrother.text = "\(Arrtickte?[indexPath.row].highPrice ?? "Default Value")"
        cell.lbl_EmpID.text = "\(Arrtickte?[indexPath.row].lastPrice ?? "Default Value")"
        cell.lbl_EmpAddress.text = "\(Arrtickte?[indexPath.row].openPrice ?? "Default Value")"
        return cell
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 200
    }
}
