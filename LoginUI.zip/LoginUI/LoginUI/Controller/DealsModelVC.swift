//
//  DealsModelVC.swift
//  LoginUI
//
//  Created by syed fazal abbas on 26/09/23.
//

import UIKit

class DealsModelVC: UIViewController {
    
    var ArrDeal : [DealsModel]?
    @IBOutlet var tblDeals: UITableView!
    override func viewDidLoad() {
        super.viewDidLoad()
        tblDeals.delegate = self
        tblDeals.dataSource = self
        registerXib()
        fetchData()
    }
    func registerXib() {
        tblDeals.register(UINib(nibName: "CellT_Employe", bundle: nil), forCellReuseIdentifier: "CellT_Employe")
    }
    func fetchData(){
        Service.shared.Deals { [weak self] (enterie, error) in
            if let error = error {
                print("Failed to fetch employees:", error)
                return
            }
            
            if let employees = enterie {
                self?.ArrDeal = employees
                DispatchQueue.main.async {
                    self?.tblDeals.reloadData()
                }
            }
        }
    }
}
extension DealsModelVC : UITableViewDelegate,UITableViewDataSource{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return ArrDeal?.count ?? Int(0.0)
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tblDeals.dequeueReusableCell(withIdentifier: "CellT_Employe") as! CellT_Employe
        cell.lbl_EmpName.text = "\(ArrDeal?[indexPath.row].dealID ?? "Default")"
        cell.lbl_EmpFather.text = ArrDeal?[indexPath.row].gameID
        cell.lbl_Mother.text = "\(ArrDeal?[indexPath.row].dealRating ?? "Default")"
        cell.lbl_EmpBrother.text = "\(ArrDeal?[indexPath.row].savings ?? "Default")"
        cell.lbl_EmpID.text = "\(ArrDeal?[indexPath.row].isOnSale ?? "Default")"
        cell.lbl_EmpAddress.text = "\(ArrDeal?[indexPath.row].normalPrice ?? "Default")"
        return cell
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 200
    }
    
}
