//
//  ColorVC.swift
//  LoginUI
//
//  Created by syed fazal abbas on 24/09/23.
//

import UIKit

class ColorVC: UIViewController {

    var ArrColor : [ColorModel] = []
    @IBOutlet var tblColor: UITableView!
    override func viewDidLoad() {
        super.viewDidLoad()
        tblColor.delegate = self
        tblColor.dataSource = self
        registerXib()
        fetchData()
    }
    func registerXib() {
        tblColor.register(UINib(nibName: "CellT_Employe", bundle: nil), forCellReuseIdentifier: "CellT_Employe")
    }
    func fetchData(){
        Service.shared.Colure { [weak self] (enterie, error) in
            if let error = error {
                print("Failed to fetch employees:", error)
                return
            }
            
            if let employees = enterie {
                self?.ArrColor = employees
                DispatchQueue.main.async {
                    self?.tblColor.reloadData()
                }
            }
        }
    }
}
extension ColorVC : UITableViewDelegate,UITableViewDataSource{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return ArrColor.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tblColor.dequeueReusableCell(withIdentifier: "CellT_Employe") as! CellT_Employe
        cell.lbl_EmpName.text = "\(ArrColor[indexPath.row].id)"
        cell.lbl_EmpFather.text = ArrColor[indexPath.row].title
        cell.lbl_Mother.text = ArrColor[indexPath.row].description
        cell.lbl_EmpBrother.text = ArrColor[indexPath.row].url
        cell.lbl_EmpID.text = ArrColor[indexPath.row].dateCreated
        cell.lbl_EmpAddress.text = "\(ArrColor[indexPath.row].hsv.saturation)"
        return cell
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 200
    }
    
}

