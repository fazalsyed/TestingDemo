//
//  BitCoinVC.swift
//  LoginUI
//
//  Created by syed fazal abbas on 07/10/23.
//

import UIKit

class BitCoinVC: UIViewController {
    
    var ArrBitCoin : [bitcoinModel] = []
    @IBOutlet var tblBitCoin: UITableView!
    override func viewDidLoad() {
        super.viewDidLoad()
        tblBitCoin.delegate = self
        tblBitCoin.dataSource = self
        registerXib()
        fetchdata()
    }
    func registerXib() {
        tblBitCoin.register(UINib(nibName: "CellT_Employe", bundle: nil), forCellReuseIdentifier: "CellT_Employe")
    }
    func fetchdata(){
        Service.shared.bitcoin { [weak self] (result : Result <[bitcoinModel],Error>) in
            switch result {
            case .success(let success):
                self?.ArrBitCoin = success
                DispatchQueue.main.sync {
                    self?.tblBitCoin.reloadData()
                }
            case .failure(let failure):
                print("Data Not Fetched",failure)
            }
        }
    }
}
extension BitCoinVC : UITableViewDelegate,UITableViewDataSource{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return ArrBitCoin.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tblBitCoin.dequeueReusableCell(withIdentifier: "CellT_Employe") as! CellT_Employe
        cell.lbl_EmpName.text = "\(ArrBitCoin[indexPath.row].ath)"
        cell.lbl_EmpFather.text = ArrBitCoin[indexPath.row].name
        cell.lbl_Mother.text = "\(ArrBitCoin[indexPath.row].price_change_percentage_24h)"
        cell.lbl_EmpBrother.text = "\(ArrBitCoin[indexPath.row].current_price)"
        cell.lbl_EmpID.text = "\(ArrBitCoin[indexPath.row].atl_change_percentage)"
        cell.lbl_EmpAddress.text = "\(ArrBitCoin[indexPath.row].atl_date)"
        return cell
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 200
    }
}

