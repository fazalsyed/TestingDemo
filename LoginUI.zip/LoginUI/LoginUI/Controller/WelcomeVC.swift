//
//  WelcomeVC.swift
//  LoginUI
//
//  Created by syed fazal abbas on 16/09/23.
//

import UIKit

class WelcomeVC: UIViewController {
    
    @IBOutlet var lblPrivacy: UILabel!
    @IBOutlet var btnSignUp: UIButton!
    @IBOutlet var btnLogin: UIButton!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        setupUI()
        lblPrivacysetUp()
        
    }
    func lblPrivacysetUp(){
        let text = "By continuing you agree to our Terms of Use and Privacy Policy"
        let attributedString = NSMutableAttributedString(string: text)
        let termsOfUseRange = NSRange(location: 31, length: 12)
        if text.count >= NSMaxRange(termsOfUseRange) {
            attributedString.addAttribute(.foregroundColor, value: UIColor.yellow, range: termsOfUseRange)
        }
        let privacyPolicyRange = NSRange(location: 48, length: 14)
        if text.count >= NSMaxRange(privacyPolicyRange) {
            attributedString.addAttribute(.foregroundColor, value: UIColor.yellow, range: privacyPolicyRange)
        }
        lblPrivacy.attributedText = attributedString
    }
    
    func setupUI(){
        btnLogin.backgroundColor = UIColor.white
        btnLogin.setTitleColor(UIColor.black, for: .normal)
        btnLogin.layer.cornerRadius = 10.0
        btnLogin.layer.borderColor = UIColor.clear.cgColor
        btnLogin.layer.borderWidth = 0
        
        btnSignUp.backgroundColor = UIColor.clear
        btnSignUp.layer.borderColor = UIColor.white.cgColor
        btnSignUp.layer.borderWidth = 1
        btnSignUp.setTitleColor(UIColor.white, for: .normal)
        btnSignUp.layer.cornerRadius = 10.0
    }
    @IBAction func btnTappedLogin(_ sender: UIButton) {
        btnLogin.isSelected.toggle()
        if btnLogin.isSelected {
            btnLogin.backgroundColor = UIColor.white
            btnLogin.setTitleColor(UIColor.black, for: .normal)
            btnLogin.layer.cornerRadius = 10.0
            btnLogin.layer.borderColor = UIColor.clear.cgColor
            btnLogin.layer.borderWidth = 0
            
            btnSignUp.backgroundColor = UIColor.clear
            btnSignUp.layer.borderColor = UIColor.white.cgColor
            btnSignUp.layer.borderWidth = 1
            btnSignUp.setTitleColor(UIColor.white, for: .normal)
            btnSignUp.layer.cornerRadius = 10.0
        } else {
            btnLogin.backgroundColor = UIColor.clear
            btnLogin.layer.borderColor = UIColor.white.cgColor
            btnLogin.layer.borderWidth = 1
            btnLogin.setTitleColor(UIColor.white, for: .normal)
            btnLogin.layer.cornerRadius = 10.0
        }
        let vc = self.storyboard?.instantiateViewController(withIdentifier: "LoginVC") as? LoginVC
        self.navigationController?.pushViewController(vc!, animated: true)
    }
    
    @IBAction func btnTappedSignUp(_ sender: UIButton) {
        btnSignUp.isSelected.toggle()
        if btnSignUp.isSelected {
            btnSignUp.backgroundColor = UIColor.white
            btnSignUp.setTitleColor(UIColor.black, for: .normal)
            btnSignUp.layer.cornerRadius = 10.0
            btnSignUp.layer.borderColor = UIColor.clear.cgColor
            btnSignUp.layer.borderWidth = 0
            
            btnLogin.backgroundColor = UIColor.clear
            btnLogin.layer.borderColor = UIColor.white.cgColor
            btnLogin.layer.borderWidth = 1
            btnLogin.setTitleColor(UIColor.white, for: .normal)
            btnLogin.layer.cornerRadius = 10.0
        } else {
            btnSignUp.backgroundColor = UIColor.clear
            btnSignUp.layer.borderColor = UIColor.white.cgColor
            btnSignUp.layer.borderWidth = 1
            btnSignUp.setTitleColor(UIColor.white, for: .normal)
            btnSignUp.layer.cornerRadius = 10.0
        }
        let vc = self.storyboard?.instantiateViewController(withIdentifier: "SignUpVC") as? SignUpVC
        self.navigationController?.pushViewController(vc!, animated: true)
    }
}
