//
//  BeerVC.swift
//  LoginUI
//
//  Created by syed fazal abbas on 25/09/23.
//

import UIKit

class BeerVC: UIViewController {

    var Arrbeer : [beersModal]? = []
    @IBOutlet var tblbeers: UITableView!
    override func viewDidLoad() {
        super.viewDidLoad()
        tblbeers.delegate = self
        tblbeers.dataSource = self
        registerXib()
        fetchData()
    }
    func registerXib() {
        tblbeers.register(UINib(nibName: "CellT_Employe", bundle: nil), forCellReuseIdentifier: "CellT_Employe")
    }
    func fetchData(){
        Service.shared.beers { [weak self] (enterie, error) in
            if let error = error {
                print("Failed to fetch employees:", error)
                return
            }
            
            if let employees = enterie {
                self?.Arrbeer = employees
                DispatchQueue.main.async {
                    self?.tblbeers.reloadData()
                }
            }
        }
    }
    }
    extension BeerVC : UITableViewDelegate,UITableViewDataSource{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return Arrbeer?.count ?? 0
    }

    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tblbeers.dequeueReusableCell(withIdentifier: "CellT_Employe") as! CellT_Employe
        cell.lbl_EmpName.text = "\(Arrbeer?[indexPath.row].id ?? 0)"
        cell.lbl_EmpFather.text = Arrbeer?[indexPath.row].brewers_tips
        cell.lbl_Mother.text = "\(Arrbeer?[indexPath.row].boil_volume.value ?? 0)"
        cell.lbl_EmpBrother.text = Arrbeer?[indexPath.row].contributed_by
        cell.lbl_EmpID.text = "\(Arrbeer?[indexPath.row].boil_volume.value ?? 0)"
        cell.lbl_EmpAddress.text = Arrbeer?[indexPath.row].ingredients.yeast
        return cell
    }

    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 200
    }

    }


