//
//  Model.swift
//  LoginUI
//
//  Created by syed fazal abbas on 24/09/23.
//

import Foundation

struct EmplodeModel : Codable{
    var status : String
    var data : [EmpDataModel]
    var message : String
}
struct EmpDataModel : Codable{
    var id : Int
    var employee_name : String
    var employee_salary : Int
    var employee_age : Int
    var profile_image : String
}
struct ProductModel : Codable{
    var id : Int
    var title : String
    var price : Float
    var description : String
    var category : String
    var image : String
    var rating : RatingDataModel
}
struct RatingDataModel : Codable{
    var rate : Float
    var count : Int
}
struct CartModel : Codable{
    var id : Int
    var userId : Int
    var date : String
    var products : [ProductData]
    var __v : Int
}
struct ProductData : Codable{
    var productId : Int
    var quantity : Int
}
struct PostModel : Codable{
    var userId : Int
    var id : Int
    var title : String
    var body : String
}
struct CommentModel : Codable{
    var postId : Int
    var id : Int
    var name : String
    var email : String
    var body : String
}

struct EnterieModel : Codable{
    var count : Int
    var entries : [EnterieDataModel]
}
struct EnterieDataModel : Codable{
    var API : String
    var Description : String
    var Auth : String
    var HTTPS : Bool
    var Cors : String
    var Link : String
    var Category : String
}
//Question.
struct ColorModel : Codable{
    var id : Int
    var title : String
    var userName : String
    var numViews : Int
    var numVotes : Int
    var numHearts : Int
    var rank : Int
    var dateCreated : String
    var hex : String
    var rgb : rgbDataModel
    var hsv : hsvDataModel
    var description : String
    var url : String
    var imageUrl : String
    var badgeUrl : String
    var apiUrl : String
}
struct rgbDataModel : Codable{
    var red : Int
    var green : Int
    var blue : Int
}
struct hsvDataModel : Codable{
    var hue : Int
    var saturation : Int
    var value : Int
}
struct Aqua : Codable {
    let status: String
    let base: ColorInfo
    let baseWithoutAlpha: ColorInfo
    let baseWithoutAlphaContrastedText: ColorInfo
    let complementary: ColorInfo
    let complementaryWithoutAlpha: ColorInfo
    let complementaryWithoutAlphaContrastedText: ColorInfo
    let grayscale: ColorInfo
    let grayscaleWithoutAlpha: ColorInfo
    let grayscaleWithoutAlphaContrastedText: ColorInfo
}
struct ColorInfo: Codable {
    let keyword: String
    let hex: ColorValue
    let rgb: ColorValue
    let hsl: ColorValue
    let hslRaw: ColorValue
}
struct ColorValue: Codable {
    let value: String
    let composition: Composition
}
struct Composition: Codable {
    let red: String
    let green: String
    let blue: String
}
struct codeModel: Codable {
    let ok: Bool
    let result: resultDataModel
}
struct resultDataModel: Codable {
    let code: String
    let short_link: String
    let full_short_link: String
    let short_link2: String
    let full_short_link2: String
    let short_link3: String
    let full_short_link3: String
    let share_link: String
    let full_share_link: String
    let original_link: String
}

struct urlModel : Codable{
    let query_status : String
    let urls : [urlDataModel]
}
struct urlDataModel : Codable{
    let id : Int
    let urlhaus_reference : String
    let url : String
    let url_status : String
    let host : String
    let date_added : String
    let threat : String
    let blacklists : blacklistsDataModel
    let reporter : String
    let larted : String
    let tags : tagsDataModel
    
}
struct blacklistsDataModel : Codable{
    let spamhaus_dbl : String
    let surbl : String
}
struct tagsDataModel : Codable{
    let tags : String
}
struct breModel: Codable {
    let id: String
    let name: String
    let breweryType: String?
    let address1: String? // Make address1 an optional
    let address2: String?
    let address3: String?
    let city: String?
    let stateProvince: String?
    let postalCode: String?
    let country: String?
    let longitude: String?
    let latitude: String?
    let phone: String?
    let websiteURL: String?
    let state: String?
    let street: String?
}
struct beersModal : Codable{
    let id : Int?
    let name : String?
    let tagline : String?
    let first_brewed : String?
    let description : String?
    let image_url : String?
    let abv : Double?
    let ibu : Double?
    let target_fg : Int?
    let target_og : Double?
    let ebc : Int?
    let srm : Double?
    let ph : Double?
    let attenuation_level : Double
    let volume : volumeDataModel
    let boil_volume : boilvolumeDataModel
    let method : methodDataModel
    let ingredients : ingredientsDataModel
    let food_pairing : [String]
    let brewers_tips : String
    let contributed_by : String
}
struct volumeDataModel : Codable{
    let value : Float
    let unit : String
}
struct boilvolumeDataModel : Codable{
    let value : Float
    let unit : String
}
struct methodDataModel : Codable{
    let mash_temp : [mashtempDataModel]
    let fermentation : fermentationDataModel
    let twist : String?
}
struct mashtempDataModel : Codable{
    let temp : tempData
    let duration : Int?
}
struct tempData : Codable{
    let value : Int
    let unit : String
}
struct tempDataModel : Codable{
    let value : Double
    let unit : String
}
struct fermentationDataModel : Codable{
    let temp : tempData
}
struct ingredientsDataModel : Codable{
    let malt : [maltDataModel]
    let hops : [hopsDataModel]
    let yeast : String
}
struct maltDataModel : Codable{
    let name : String
    let amount : tempDataModel
}
struct hopsDataModel : Codable{
    let name : String
    let amount : tempDataModel
    let add : String
    let attribute : String
}
struct auctionData : Codable{
    let dt : String?
    let winning_bid_max : Double?
    let winning_bid_min : Double?
    let winning_bid_mean : Double?
    let auction_trading_volume : Double?
    let auction_lots_count : Int?
    let all_auctions_lots_count : Int?
    let auction_name : String?
    let auction_slug : String?
}
struct activityModel : Codable{
    let activity : String?
    let type : String?
    let participants : Float?
    let price : Float?
    let link : String?
    let key : String?
    let accessibility : Float?
}
struct DealsModel : Codable{
    let internalName : String?
    let title : String?
    let metacriticLink : String?
    let dealID : String?
    let storeID : String?
    let gameID : String?
    let salePrice : String?
    let normalPrice : String?
    let isOnSale : String?
    let savings : String?
    let metacriticScore : String?
    let steamRatingText : String?
    let steamRatingPercent : String?
    let steamAppID : String?
    let releaseDate : Int?
    let lastChange : Int?
    let dealRating : String?
    let thumb : String?
}
struct featureModel : Codable{
    let count : Int
    let results : [resultsDataModel]
}
struct resultsDataModel : Codable{
    let index : String
    let name : String
    let url : String
}
struct ticketModel : Codable{
    let symbol : String?
    let baseAsset : String?
    let quoteAsset : String?
    let openPrice : String?
    let lowPrice : String?
    let highPrice : String?
    let lastPrice : String?
    let volume : String?
    let bidPrice : String?
    let askPrice : String?
    let at : Int?
}
struct EngineModel : Codable{
    let browser_family : String?
    let client : clientDataModel
    let device : deviceDataModel
    let os : osDataModel
    let os_family : String?
    let user_agent : String?
}
struct clientDataModel : Codable{
    let engine : String?
    let engine_version : String?
    let name : String?
    let type : String?
    let version : String?
}
struct deviceDataModel : Codable{
    let brand : String?
    let model : String?
    let type : String?
}
struct osDataModel : Codable{
    let name : String?
    let platform : String?
    let version : String?
}
//struct ExchangeRateData: Codable {
//    let disclaimer: String
//    let license: String
//    let timestamp: Int
//    let base: String
//    let rates: [String: Double]
//}
struct ExchangeRate {
    let currencyCode: String
    let rate: Double
}
struct ExchangeRateResponse: Decodable {
    let disclaimer: String
    let license: String
    let timestamp: Int
    let base: String
    let rates: [String: Double]
}

struct TempModel : Codable{
    let metadata : metadataDataModel
    let items : itemsDataModel
    let api_info : apiinfoDataModel
}
struct metadataDataModel : Codable{
    let stations : [stationsDataModel]
    let reading_type : String
    let reading_unit : String
}
struct itemsDataModel : Codable{
    
}
struct apiinfoDataModel : Codable{
    
}
struct stationsDataModel : Codable{
    
}
struct reditModel : Codable{
    let no_of_comments : Int
    let sentiment : String
    let sentiment_score : Double
    let ticker : String
}
struct characterModel : Codable{
    let id : Int
    let name : String
    let status : String
    let species : String
    let type : String
    let gender : String
    let origin : originDataModel
    let location : originDataModel
    let image : String
    let episode : [String]
    let url : String
    let created : String
}

struct originDataModel : Codable{
    let name : String
    let url : String?
}

struct currentPrice : Codable{
    let time : timeDataModel
    let disclaimer : String
    let chartName : String
    let bpi : bpiDataModel
}
struct timeDataModel : Codable{
    let updated : String
    let updatedISO : String
    let updateduk : String
}
struct bpiDataModel : Codable{
    let USD : USDDataModel
    let GBP : USDDataModel
    let EUR : USDDataModel
}
struct USDDataModel : Codable{
    let code : String
    let symbol : String
    let rate : String
    let description : String
    let rate_float : Double
}
struct bitcoinModel : Codable{
    let id : String
    let symbol : String
    let name : String
    let image : String
    let current_price : Double
    let market_cap : Int
    let market_cap_rank : Int
    let fully_diluted_valuation : Int?
    let total_volume : Double?
    let high_24h : Double
    let price_change_24h : Double
    let price_change_percentage_24h : Float
    let market_cap_change_24h : Double?
    let market_cap_change_percentage_24h : Float
    let circulating_supply : Double
    let total_supply : Double?
    let max_supply : Double?
    let ath : Double?
    let ath_change_percentage : Double
    let atl : Double
    let atl_change_percentage : Double
    let atl_date : String
    let roi : timeDataModels?
    let last_updated : String
}
struct timeDataModels : Codable{
    let times : Double
    let currency : String
    let percentage : Double
}

//struct ticketApiModel : Codable{
//    let data : [ticketApiDataModel]
//    let info : ticktinfoDataModel
//}
//struct ticktinfoDataModel : Codable{
//    let coins_num : Int
//    let time : Int
//}
//struct ticketApiDataModel : Codable{
//    let id : String
//    let symbol : String
//    let name : String
//    let nameid : String
//    let rank : Int
//    let price_usd : String
//    let percent_change_24h : String
//    let percent_change_1h : String
//    let percent_change_7d : String
//    let market_cap_usd : String
//    let volume24 : Double
//    let volume24a : Double
//    let csupply : String
//    let tsupply : String
//    let msupply : String
//}

struct ticketApiModel: Codable {
    let data: [ticketApiDataModel]
    let info: ticktinfoDataModel
}

// MARK: - Datum
struct ticketApiDataModel: Codable {
    let id, symbol, name, nameid: String
    let rank: Int
    let priceUsd, percentChange24H, percentChange1H, percentChange7D: String
    let priceBtc, marketCapUsd: String
    let volume24, volume24A: Double
    let csupply: String
    let tsupply, msupply: String?
    
    enum CodingKeys: String, CodingKey {
        case id, symbol, name, nameid, rank
        case priceUsd = "price_usd"
        case percentChange24H = "percent_change_24h"
        case percentChange1H = "percent_change_1h"
        case percentChange7D = "percent_change_7d"
        case priceBtc = "price_btc"
        case marketCapUsd = "market_cap_usd"
        case volume24
        case volume24A = "volume24a"
        case csupply, tsupply, msupply
    }
}

// MARK: - Info
struct ticktinfoDataModel: Codable {
    let coinsNum, time: Int
    
    enum CodingKeys: String, CodingKey {
        case coinsNum = "coins_num"
        case time
    }
}
struct MarketModel: Codable {
    let price: Double
    let exchange, pair: String
    let pairPrice, volume: Double
}
struct ExhageModel: Codable {
    let success: Bool
    let error: ErrorDataModel
}

// MARK: - Error
struct ErrorDataModel: Codable {
    let code: Int
    let type, info: String
}

struct BranchModel: Codable {
    let branch, centre, district, state: String?
    let address, contact: String?
    let imps: Bool?
    let city: String?
    let upi: Bool?
    let micr: String?
    let rtgs, neft: Bool?
    let swift: String?
    let iso3166, bank, bankcode, ifsc: String?
}
struct assetModel: Codable {
    let symbol, baseAsset: String
    let quoteAsset: QuoteAsset
    let openPrice, lowPrice, highPrice, lastPrice: String
    let volume, bidPrice, askPrice: String
    let at: Int
}
enum QuoteAsset: String, Codable {
    case btc = "btc"
    case inr = "inr"
    case usdt = "usdt"
    case wrx = "wrx"
}
struct MacintoshModel: Codable {
    let browserFamily: String
    let client: Client
    let device: Device
    let os: OS
    let osFamily, userAgent: String
}
// MARK: - Client
struct Client: Codable {
    let engine, engineVersion, name, type: String
    let version: String
}

// MARK: - Device
struct Device: Codable {
    let brand, model, type: String
}

// MARK: - OS
struct OS: Codable {
    let name, platform, version: String
}
struct GrabModel: Codable {
    let domain: String
    let icons: [Icon]
}

// MARK: - Icon
struct Icon: Codable {
    let src: String
    let type, sizes: String?
}
struct FilterModel: Codable {
    let id: Int?
    let name: String?
    let description: String?
    let licenseID: Int?
    let syntaxIDS, languageIDS, tagIDS: [Int]?
    let primaryViewURL: String?
    let maintainerIDS: [Int]?
}
//struct WelcomeElement : Codable{
//    let _id : String
//    let createdAt : String
//    let exposure : String
//    let model : String
//    let name : String
//    let sensors : [sensorDataModel]
//    let updatedAt : String
//    let currentLocation : currentLocationDataModel
//    let grouptag : [String]
//}
//struct sensorDataModel : Codable{
//    let _id : String
//    let lastMeasurement : String
//    let sensorType : String
//    let title : String
//    let unit : String
//}
//struct currentLocationDataModel : Codable{
//    let coordinates : [Int]
//    let type : String
//    let timestamp : String
//}
struct WelcomeElement: Codable {
    let id, createdAt: String
    let exposure: Exposure
    let model: Model
    let name: String
    let sensors: [Sensor]
    let updatedAt: String
    let currentLocation: CurrentLocation
    let grouptag: [String]?
    let description: String?
    let lastMeasurementAt: String?
    let weblink: String?
    let image: String?
    
    enum CodingKeys: String, CodingKey {
        case id = "_id"
        case createdAt, exposure, model, name, sensors, updatedAt, currentLocation, grouptag, description, lastMeasurementAt, weblink, image
    }
}

// MARK: - CurrentLocation
struct CurrentLocation: Codable {
    let coordinates: [Double]
    let type: TypeEnum
    let timestamp: String
}

enum TypeEnum: String, Codable {
    case point = "Point"
}

enum Exposure: String, Codable {
    case indoor = "indoor"
    case mobile = "mobile"
    case outdoor = "outdoor"
}

enum Model: String, Codable {
    case homeWifi = "homeWifi"
}

// MARK: - Sensor
struct Sensor: Codable {
    let id: String
    let lastMeasurement: String?
    let sensorType, title, unit: String
    let icon: Icons?
    
    enum CodingKeys: String, CodingKey {
        case id = "_id"
        case lastMeasurement, sensorType, title, unit, icon
    }
}

enum Icons: String, Codable {
    case osemBarometer = "osem-barometer"
    case osemBattery = "osem-battery"
    case osemBrightness = "osem-brightness"
    case osemCloud = "osem-cloud"
    case osemCo2 = "osem-co2"
    case osemDashboard = "osem-dashboard"
    case osemGauge = "osem-gauge"
    case osemHumidity = "osem-humidity"
    case osemMicrophone = "osem-microphone"
    case osemMoisture = "osem-moisture"
    case osemNotAvailable = "osem-not-available"
    case osemParticulateMatter = "osem-particulate-matter"
    case osemRadioactive = "osem-radioactive"
    case osemTemperatureCelsius = "osem-temperature-celsius"
    case osemThermometer = "osem-thermometer"
    case osemUmberella = "osem-umberella"
    case osemUmbrella = "osem-umbrella"
    case osemVolumeUp = "osem-volume-up"
    case osemWifi = "osem-wifi"
    case osemWindspeed = "osem-windspeed"
}

typealias Welcome = [WelcomeElement]

struct metasDataModel : Codable{
    let stations : [stationDataModel]
    let reading_type : String
    let reading_unit : String
}
struct stationDataModel : Codable{
    let id : String
    let device_id : String
    let name : String
    let location : locationDataModel
    
}
struct locationDataModel : Codable{
    let latitude : Float
    let longitude : Float
}

//struct DictData : Codable{
//    let word : String
//    let phonetic : String
//    let phonetics : [phoneticsDataModel]
//    let meanings : [meaningsDataModel]?
//    let license : licenseDataModel
//    let sourceUrls : [String]
//}
//struct phoneticsDataModel : Codable{
//    let text : String
//    let audio : String
//    let sourceUrl : String
//    let license : licenseDataModel
//}
//struct licenseDataModel : Codable{
//    let name : String
//    let url : String
//}
//struct meaningsDataModel : Codable{
//    let partOfSpeech : String
//    let definitions : [definitionsDataModel]
//}
//struct definitionsDataModel : Codable{
//    let definition : String?
//    let synonyms : [String]
//    let antonyms : [String]
//    let example : String
//}
//
struct DictData: Codable {
    let word, phonetic: String
    let phonetics: [Phonetic]
    let meanings: [Meaning]
    let license: License
    let sourceUrls: [String]
}

// MARK: - License
struct License: Codable {
    let name: String
    let url: String
}

// MARK: - Meaning
struct Meaning: Codable {
    let partOfSpeech: String
    let definitions: [Definition]
    let synonyms: [JSONAny]
    let antonyms: [String]
}

// MARK: - Definition
struct Definition: Codable {
    let definition: String
    let synonyms, antonyms: [JSONAny]
    let example: String?
}

// MARK: - Phonetic
struct Phonetic: Codable {
    let text: String
    let audio: String
    let sourceURL: String
    let license: License
    
    enum CodingKeys: String, CodingKey {
        case text, audio
        case sourceURL = "sourceUrl"
        case license
    }
}

typealias DistAlias = [DictData]
// MARK: - Encode/decode helpers

class JSONNull: Codable, Hashable {
    
    public static func == (lhs: JSONNull, rhs: JSONNull) -> Bool {
        return true
    }
    
    public var hashValue: Int {
        return 0
    }
    
    public init() {}
    
    public required init(from decoder: Decoder) throws {
        let container = try decoder.singleValueContainer()
        if !container.decodeNil() {
            throw DecodingError.typeMismatch(JSONNull.self, DecodingError.Context(codingPath: decoder.codingPath, debugDescription: "Wrong type for JSONNull"))
        }
    }
    
    public func encode(to encoder: Encoder) throws {
        var container = encoder.singleValueContainer()
        try container.encodeNil()
    }
}

class JSONCodingKey: CodingKey {
    let key: String
    
    required init?(intValue: Int) {
        return nil
    }
    
    required init?(stringValue: String) {
        key = stringValue
    }
    
    var intValue: Int? {
        return nil
    }
    
    var stringValue: String {
        return key
    }
}

class JSONAny: Codable {
    
    let value: Any
    
    static func decodingError(forCodingPath codingPath: [CodingKey]) -> DecodingError {
        let context = DecodingError.Context(codingPath: codingPath, debugDescription: "Cannot decode JSONAny")
        return DecodingError.typeMismatch(JSONAny.self, context)
    }
    
    static func encodingError(forValue value: Any, codingPath: [CodingKey]) -> EncodingError {
        let context = EncodingError.Context(codingPath: codingPath, debugDescription: "Cannot encode JSONAny")
        return EncodingError.invalidValue(value, context)
    }
    
    static func decode(from container: SingleValueDecodingContainer) throws -> Any {
        if let value = try? container.decode(Bool.self) {
            return value
        }
        if let value = try? container.decode(Int64.self) {
            return value
        }
        if let value = try? container.decode(Double.self) {
            return value
        }
        if let value = try? container.decode(String.self) {
            return value
        }
        if container.decodeNil() {
            return JSONNull()
        }
        throw decodingError(forCodingPath: container.codingPath)
    }
    
    static func decode(from container: inout UnkeyedDecodingContainer) throws -> Any {
        if let value = try? container.decode(Bool.self) {
            return value
        }
        if let value = try? container.decode(Int64.self) {
            return value
        }
        if let value = try? container.decode(Double.self) {
            return value
        }
        if let value = try? container.decode(String.self) {
            return value
        }
        if let value = try? container.decodeNil() {
            if value {
                return JSONNull()
            }
        }
        if var container = try? container.nestedUnkeyedContainer() {
            return try decodeArray(from: &container)
        }
        if var container = try? container.nestedContainer(keyedBy: JSONCodingKey.self) {
            return try decodeDictionary(from: &container)
        }
        throw decodingError(forCodingPath: container.codingPath)
    }
    
    static func decode(from container: inout KeyedDecodingContainer<JSONCodingKey>, forKey key: JSONCodingKey) throws -> Any {
        if let value = try? container.decode(Bool.self, forKey: key) {
            return value
        }
        if let value = try? container.decode(Int64.self, forKey: key) {
            return value
        }
        if let value = try? container.decode(Double.self, forKey: key) {
            return value
        }
        if let value = try? container.decode(String.self, forKey: key) {
            return value
        }
        if let value = try? container.decodeNil(forKey: key) {
            if value {
                return JSONNull()
            }
        }
        if var container = try? container.nestedUnkeyedContainer(forKey: key) {
            return try decodeArray(from: &container)
        }
        if var container = try? container.nestedContainer(keyedBy: JSONCodingKey.self, forKey: key) {
            return try decodeDictionary(from: &container)
        }
        throw decodingError(forCodingPath: container.codingPath)
    }
    
    static func decodeArray(from container: inout UnkeyedDecodingContainer) throws -> [Any] {
        var arr: [Any] = []
        while !container.isAtEnd {
            let value = try decode(from: &container)
            arr.append(value)
        }
        return arr
    }
    
    static func decodeDictionary(from container: inout KeyedDecodingContainer<JSONCodingKey>) throws -> [String: Any] {
        var dict = [String: Any]()
        for key in container.allKeys {
            let value = try decode(from: &container, forKey: key)
            dict[key.stringValue] = value
        }
        return dict
    }
    
    static func encode(to container: inout UnkeyedEncodingContainer, array: [Any]) throws {
        for value in array {
            if let value = value as? Bool {
                try container.encode(value)
            } else if let value = value as? Int64 {
                try container.encode(value)
            } else if let value = value as? Double {
                try container.encode(value)
            } else if let value = value as? String {
                try container.encode(value)
            } else if value is JSONNull {
                try container.encodeNil()
            } else if let value = value as? [Any] {
                var container = container.nestedUnkeyedContainer()
                try encode(to: &container, array: value)
            } else if let value = value as? [String: Any] {
                var container = container.nestedContainer(keyedBy: JSONCodingKey.self)
                try encode(to: &container, dictionary: value)
            } else {
                throw encodingError(forValue: value, codingPath: container.codingPath)
            }
        }
    }
    
    static func encode(to container: inout KeyedEncodingContainer<JSONCodingKey>, dictionary: [String: Any]) throws {
        for (key, value) in dictionary {
            let key = JSONCodingKey(stringValue: key)!
            if let value = value as? Bool {
                try container.encode(value, forKey: key)
            } else if let value = value as? Int64 {
                try container.encode(value, forKey: key)
            } else if let value = value as? Double {
                try container.encode(value, forKey: key)
            } else if let value = value as? String {
                try container.encode(value, forKey: key)
            } else if value is JSONNull {
                try container.encodeNil(forKey: key)
            } else if let value = value as? [Any] {
                var container = container.nestedUnkeyedContainer(forKey: key)
                try encode(to: &container, array: value)
            } else if let value = value as? [String: Any] {
                var container = container.nestedContainer(keyedBy: JSONCodingKey.self, forKey: key)
                try encode(to: &container, dictionary: value)
            } else {
                throw encodingError(forValue: value, codingPath: container.codingPath)
            }
        }
    }
    
    static func encode(to container: inout SingleValueEncodingContainer, value: Any) throws {
        if let value = value as? Bool {
            try container.encode(value)
        } else if let value = value as? Int64 {
            try container.encode(value)
        } else if let value = value as? Double {
            try container.encode(value)
        } else if let value = value as? String {
            try container.encode(value)
        } else if value is JSONNull {
            try container.encodeNil()
        } else {
            throw encodingError(forValue: value, codingPath: container.codingPath)
        }
    }
    
    public required init(from decoder: Decoder) throws {
        if var arrayContainer = try? decoder.unkeyedContainer() {
            self.value = try JSONAny.decodeArray(from: &arrayContainer)
        } else if var container = try? decoder.container(keyedBy: JSONCodingKey.self) {
            self.value = try JSONAny.decodeDictionary(from: &container)
        } else {
            let container = try decoder.singleValueContainer()
            self.value = try JSONAny.decode(from: container)
        }
    }
    
    public func encode(to encoder: Encoder) throws {
        if let arr = self.value as? [Any] {
            var container = encoder.unkeyedContainer()
            try JSONAny.encode(to: &container, array: arr)
        } else if let dict = self.value as? [String: Any] {
            var container = encoder.container(keyedBy: JSONCodingKey.self)
            try JSONAny.encode(to: &container, dictionary: dict)
        } else {
            var container = encoder.singleValueContainer()
            try JSONAny.encode(to: &container, value: self.value)
        }
    }
}

struct TelePortModel : Codable{
    let _links : linksDataModel
    let categories : [categoriesDataModel]
    let summary : String
    let teleport_city_score : Double
    
}
struct linksDataModel : Codable{
    let curies : [curiesDataModel]
}
struct curiesDataModel : Codable{
    let href : String
    let name : String
    let templated : Bool
}
struct categoriesDataModel : Codable{
    let color : String
    let name : String
    let score_out_of_10 : Double
}

struct unversitiesModel : Codable{
    let Count : Int
    let Message : String
    let SearchCriteria : String
    let Results : [ResultDataModel]
}
struct ResultDataModel : Codable{
    let MakeId : Int
    let MakeName : String
    let VehicleTypeId : Int
    let VehicleTypeName : String
}
struct asterModel : Codable{
    let results : [resultedDataModel]
}
struct resultedDataModel : Codable{
    let center_dec : Double
    let center_ra : Double
    let key : String
    let mag : Double
    let obs_id : String
    let offset : Double
    let pixel_loc_x: Double
    let pixel_loc_y: Double
    let pos_err_ang: String
    let pos_err_major: String
    let predicted_dec: Double
    let predicted_ra: Double
    let time: String
    let triplet: String
    let veloc_sn: Double
    let veloc_we: Double
}

